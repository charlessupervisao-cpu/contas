<?php
declare(strict_types=1);

final class Auth
{
    public static function startSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        $cookiePath = app_base_path() !== '' ? app_base_path() . '/' : '/';
        session_name('pollicontas_session');
        session_set_cookie_params([
            'lifetime' => 60 * 60 * 24 * 7,
            'path' => $cookiePath,
            'secure' => is_https(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }

    public static function user(): ?array
    {
        if (empty($_SESSION['user']) || !is_array($_SESSION['user'])) {
            return null;
        }
        $u = $_SESSION['user'];
        $u['role'] = normalize_role((string) ($u['role'] ?? 'CONSULTA'));
        return $u;
    }

    public static function login(string $email, string $password): ?array
    {
        $pdo = Database::pdo();
        $stmt = $pdo->prepare('SELECT * FROM `User` WHERE email = ? LIMIT 1');
        $stmt->execute([strtolower(trim($email))]);
        $row = $stmt->fetch();
        if (!$row || !(int) $row['active']) {
            return null;
        }
        if (!password_verify($password, $row['passwordHash'])) {
            return null;
        }
        $user = [
            'id' => $row['id'],
            'name' => $row['name'],
            'email' => $row['email'],
            'role' => normalize_role($row['role']),
        ];
        // Regenera ANTES de gravar o usuário — evita sessão vazia em alguns hosts cPanel.
        session_regenerate_id(true);
        $_SESSION['user'] = $user;
        return $user;
    }

    public static function logout(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', (bool) $p['secure'], (bool) $p['httponly']);
        }
        session_destroy();
    }

    public static function requireLogin(?string $area = null): array
    {
        $user = self::user();
        if (!$user) {
            redirect('/login.php');
        }
        if ($area !== null && !can_view($user['role'], $area)) {
            flash_set('danger', 'Você não tem permissão para acessar esta área.');
            redirect('/admin/index.php');
        }
        return $user;
    }

    public static function requireMaster(): array
    {
        $user = self::requireLogin();
        if (!can_launch($user['role'])) {
            flash_set('danger', 'Somente o perfil Master pode realizar esta ação.');
            redirect('/admin/index.php');
        }
        return $user;
    }
}
