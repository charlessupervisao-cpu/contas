<?php
declare(strict_types=1);

final class Lancamento
{
    public static function listAccountsOrdered(string $campaignId): array
    {
        $stmt = Database::pdo()->prepare(
            'SELECT * FROM `BankAccount` WHERE campaignId = ? AND active = 1 ORDER BY sortOrder ASC, createdAt ASC'
        );
        $stmt->execute([$campaignId]);
        return $stmt->fetchAll();
    }

    public static function getDefaultAccountId(string $campaignId, string $kind, string $code): ?string
    {
        $stmt = Database::pdo()->prepare(
            'SELECT bankAccountId FROM `AccountMapping` WHERE campaignId = ? AND kind = ? AND code = ? LIMIT 1'
        );
        $stmt->execute([$campaignId, $kind, $code]);
        $row = $stmt->fetch();
        return $row['bankAccountId'] ?? null;
    }

    public static function upsertMappings(string $campaignId, array $items): void
    {
        $pdo = Database::pdo();
        foreach ($items as $item) {
            $kind = (string) $item['kind'];
            $code = (string) $item['code'];
            $bankAccountId = $item['bankAccountId'] ?? null;

            if (!$bankAccountId) {
                $del = $pdo->prepare('DELETE FROM `AccountMapping` WHERE campaignId = ? AND kind = ? AND code = ?');
                $del->execute([$campaignId, $kind, $code]);
                continue;
            }

            $sel = $pdo->prepare('SELECT id FROM `AccountMapping` WHERE campaignId = ? AND kind = ? AND code = ? LIMIT 1');
            $sel->execute([$campaignId, $kind, $code]);
            $existing = $sel->fetch();
            $now = now_sql();
            if ($existing) {
                $upd = $pdo->prepare('UPDATE `AccountMapping` SET bankAccountId = ?, updatedAt = ? WHERE id = ?');
                $upd->execute([$bankAccountId, $now, $existing['id']]);
            } else {
                $ins = $pdo->prepare(
                    'INSERT INTO `AccountMapping` (id, campaignId, kind, code, bankAccountId, createdAt, updatedAt) VALUES (?,?,?,?,?,?,?)'
                );
                $ins->execute([cuid(), $campaignId, $kind, $code, $bankAccountId, $now, $now]);
            }
        }
    }

    public static function seedDefaultMappings(string $campaignId, array $accountIds): void
    {
        if (!$accountIds) {
            return;
        }
        $a = static fn (int $i) => $accountIds[min($i, count($accountIds) - 1)];

        $expenseDefaults = [
            'COMITE' => 0, 'GRAFICA' => 0, 'COMUNICACAO' => 0,
            'INTERNET' => 2, 'IMPULSIONAMENTO' => 2,
            'VEICULOS' => 3, 'COMBUSTIVEIS' => 3, 'CABOS_ELEITORAIS' => 1,
        ];
        $revenueDefaults = [
            'DOADOR_PF' => 0, 'FUNDO_PARTIDARIO' => 1, 'VAQUINHA_ELEITORAL' => 2,
        ];

        $items = [];
        foreach ($expenseDefaults as $code => $idx) {
            $items[] = ['kind' => 'EXPENSE_CATEGORY', 'code' => $code, 'bankAccountId' => $a($idx)];
        }
        foreach ($revenueDefaults as $code => $idx) {
            $items[] = ['kind' => 'REVENUE_SOURCE', 'code' => $code, 'bankAccountId' => $a($idx)];
        }
        self::upsertMappings($campaignId, $items);
    }

    /** @return array{ok:bool,error?:string,data?:array} */
    public static function create(array $input, string $userId): array
    {
        $amount = (float) ($input['amount'] ?? 0);
        $date = parse_date_input($input['date'] ?? null);
        $bankAccountId = (string) ($input['bankAccountId'] ?? '');
        $kind = (string) ($input['kind'] ?? '');

        if ($amount <= 0) {
            return ['ok' => false, 'error' => 'Valor inválido.'];
        }
        if ($bankAccountId === '') {
            return ['ok' => false, 'error' => 'Selecione a conta bancária onde o lançamento será contabilizado.'];
        }

        $pdo = Database::pdo();
        $campaign = $pdo->query('SELECT * FROM `Campaign` ORDER BY createdAt ASC LIMIT 1')->fetch();
        if (!$campaign) {
            return ['ok' => false, 'error' => 'Campanha não encontrada.'];
        }

        $accStmt = $pdo->prepare('SELECT * FROM `BankAccount` WHERE id = ? AND active = 1 AND campaignId = ? LIMIT 1');
        $accStmt->execute([$bankAccountId, $campaign['id']]);
        $account = $accStmt->fetch();
        if (!$account) {
            return ['ok' => false, 'error' => 'Conta bancária inválida.'];
        }

        if ($kind === 'RECEITA') {
            return self::createReceita($pdo, $campaign, $account, $input, $userId, $amount, $date);
        }
        if ($kind === 'DESPESA') {
            return self::createDespesa($pdo, $campaign, $account, $input, $userId, $amount, $date);
        }
        return ['ok' => false, 'error' => 'Tipo de lançamento inválido.'];
    }

    private static function createReceita(PDO $pdo, array $campaign, array $account, array $input, string $userId, float $amount, string $date): array
    {
        $source = (string) ($input['source'] ?? '');
        if (!isset(REVENUE_SOURCES[$source])) {
            return ['ok' => false, 'error' => 'Fonte de recurso inválida.'];
        }

        $donorCpf = null;
        if ($source === 'DOADOR_PF') {
            $donorCpf = only_digits((string) ($input['donorCpf'] ?? ''));
            if (!is_valid_cpf($donorCpf)) {
                return ['ok' => false, 'error' => 'CPF do doador inválido.'];
            }
            if (trim((string) ($input['donorName'] ?? '')) === '') {
                return ['ok' => false, 'error' => 'Nome do doador é obrigatório.'];
            }
        }

        $description = trim((string) ($input['description'] ?? '')) ?: REVENUE_SOURCES[$source];
        $now = now_sql();
        $revenueId = cuid();
        $txId = cuid();

        try {
            $pdo->beginTransaction();
            $pdo->prepare(
                'INSERT INTO `Revenue` (id, campaignId, source, donorName, donorCpf, amount, date, description, receiptNumber, bankAccountId, createdById, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                $revenueId, $campaign['id'], $source,
                $input['donorName'] ?? null, $donorCpf, $amount, $date, $description,
                $input['receiptNumber'] ?? null, $account['id'], $userId, $now, $now,
            ]);

            $pdo->prepare('UPDATE `BankAccount` SET balance = balance + ?, updatedAt = ? WHERE id = ?')
                ->execute([$amount, $now, $account['id']]);

            $pdo->prepare(
                'INSERT INTO `BankTransaction` (id, bankAccountId, date, description, amount, type, documentRef, status, matchedRevenueId, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                $txId, $account['id'], $date, "Crédito — {$description}", $amount, 'CREDITO',
                $input['receiptNumber'] ?? null, 'PENDENTE', $revenueId, $now, $now,
            ]);

            $pdo->prepare(
                'INSERT INTO `AuditLog` (id, userId, action, entity, entityId, details, createdAt) VALUES (?,?,?,?,?,?,?)'
            )->execute([
                cuid(), $userId, 'LAUNCH', 'Revenue', $revenueId,
                sprintf('Receita %s R$ %.2f → %s · conciliação %s', REVENUE_SOURCES[$source], $amount, $account['label'], substr($txId, -6)),
                $now,
            ]);

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            return ['ok' => false, 'error' => 'Falha ao gravar receita: ' . $e->getMessage()];
        }

        return ['ok' => true, 'data' => ['kind' => 'RECEITA', 'id' => $revenueId]];
    }

    private static function createDespesa(PDO $pdo, array $campaign, array $account, array $input, string $userId, float $amount, string $date): array
    {
        $category = (string) ($input['category'] ?? '');
        if (!isset(EXPENSE_CATEGORIES[$category])) {
            return ['ok' => false, 'error' => 'Categoria inválida.'];
        }
        $description = trim((string) ($input['description'] ?? ''));
        if ($description === '') {
            return ['ok' => false, 'error' => 'Descrição é obrigatória.'];
        }

        $nfeKey = only_digits((string) ($input['nfeKey'] ?? ''));
        if ($nfeKey === '') {
            return ['ok' => false, 'error' => 'Chave da NF-e é obrigatória (44 dígitos, como na DANFE).'];
        }
        if (strlen($nfeKey) !== 44) {
            return ['ok' => false, 'error' => 'A chave da NF-e deve ter exatamente 44 dígitos.'];
        }
        $nfe = validate_nfe_key($nfeKey);
        $forceInvalid = !empty($input['allowInvalidNfe']);
        if (!$nfe['valid'] && !$forceInvalid) {
            return [
                'ok' => false,
                'error' => 'NF-e inválida: ' . ($nfe['reason'] ?? '') . ' Marque “registrar mesmo inválida” para o gestor analisar.',
            ];
        }

        $dup = $pdo->prepare('SELECT id FROM `Expense` WHERE nfeKey = ? LIMIT 1');
        $dup->execute([$nfeKey]);
        if ($dup->fetch()) {
            return ['ok' => false, 'error' => 'Esta chave de NF-e já foi lançada no sistema.'];
        }
        $nfeIsValid = !empty($nfe['valid']);

        if ($category === 'VEICULOS' || $category === 'COMBUSTIVEIS') {
            $sumStmt = $pdo->prepare(
                "SELECT COALESCE(SUM(amount),0) AS total FROM `Expense`
                 WHERE campaignId = ? AND status <> 'CANCELADA' AND category IN ('VEICULOS','COMBUSTIVEIS')"
            );
            $sumStmt->execute([$campaign['id']]);
            $used = (float) $sumStmt->fetch()['total'] + $amount;
            $limit = (float) $campaign['totalBudget'] * VEHICLE_FUEL_LIMIT_RATIO;
            if ($used > $limit) {
                return [
                    'ok' => false,
                    'error' => sprintf('Limite de 20%% do orçamento para Veículos+Combustíveis excedido (R$ %.2f).', $limit),
                ];
            }
        }

        $supplierName = trim((string) ($input['supplierName'] ?? ''));
        $supplierDoc = isset($input['supplierDoc']) ? only_digits((string) $input['supplierDoc']) : null;
        $supplierId = $input['supplierId'] ?? null;
        if ($supplierId) {
            $s = $pdo->prepare('SELECT * FROM `Supplier` WHERE id = ? LIMIT 1');
            $s->execute([$supplierId]);
            $supplier = $s->fetch();
            if (!$supplier) {
                return ['ok' => false, 'error' => 'Fornecedor não encontrado.'];
            }
            $supplierName = $supplier['name'];
            $supplierDoc = $supplier['document'] ?: $supplierDoc;
        }
        if ($supplierName === '') {
            return ['ok' => false, 'error' => 'Fornecedor é obrigatório.'];
        }

        $now = now_sql();
        $expenseId = cuid();
        $txId = cuid();

        try {
            $pdo->beginTransaction();
            $pdo->prepare(
                'INSERT INTO `Expense` (id, campaignId, category, supplierName, supplierDoc, supplierId, description, amount, date, status, nfeKey, nfeValid, nfeValidatedAt, bankAccountId, caboId, vehicleId, createdById, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                $expenseId, $campaign['id'], $category, $supplierName, $supplierDoc ?: null, $supplierId ?: null,
                $description, $amount, $date, 'PAGA', $nfeKey, $nfeIsValid ? 1 : 0, $nfeIsValid ? $now : null, $account['id'],
                $input['caboId'] ?? null, $input['vehicleId'] ?? null, $userId, $now, $now,
            ]);

            $pdo->prepare('UPDATE `BankAccount` SET balance = balance - ?, updatedAt = ? WHERE id = ?')
                ->execute([$amount, $now, $account['id']]);

            $pdo->prepare(
                'INSERT INTO `BankTransaction` (id, bankAccountId, date, description, amount, type, documentRef, status, matchedExpenseId, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                $txId, $account['id'], $date, "Débito — {$description}", -$amount, 'DEBITO',
                substr($nfeKey, 0, 20), 'PENDENTE', $expenseId, $now, $now,
            ]);

            $pdo->prepare(
                'INSERT INTO `AuditLog` (id, userId, action, entity, entityId, details, createdAt) VALUES (?,?,?,?,?,?,?)'
            )->execute([
                cuid(), $userId, 'LAUNCH', 'Expense', $expenseId,
                sprintf('Despesa %s R$ %.2f → %s · conciliação %s', EXPENSE_CATEGORIES[$category], $amount, $account['label'], substr($txId, -6)),
                $now,
            ]);

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            return ['ok' => false, 'error' => 'Falha ao gravar despesa: ' . $e->getMessage()];
        }

        return ['ok' => true, 'data' => ['kind' => 'DESPESA', 'id' => $expenseId]];
    }
}
