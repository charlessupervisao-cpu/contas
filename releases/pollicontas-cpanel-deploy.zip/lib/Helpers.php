<?php
declare(strict_types=1);

function cuid(): string
{
    $bytes = random_bytes(12);
    return 'c' . bin2hex($bytes) . substr(str_replace('.', '', uniqid('', true)), -8);
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function only_digits(string $value): string
{
    return preg_replace('/\D+/', '', $value) ?? '';
}

/** Formata chave NF-e de 44 dígitos em blocos de 4 (exibição). */
function format_nfe_key(string $key): string
{
    $digits = only_digits($key);
    if ($digits === '') {
        return '';
    }
    return trim(chunk_split($digits, 4, ' '));
}

/** True quando há chave de acesso (44 dígitos) — condição para exibir “Visualizar nota”. */
function nfe_has_access_key(?string $key): bool
{
    return strlen(only_digits((string) $key)) === 44;
}

/**
 * URL interna que redireciona para o DANFE (ConsultaDANFE) pela chave de acesso.
 * Só use na UI quando nfe_has_access_key() for verdadeiro.
 */
function nfe_nota_url(?string $expenseId = null, string $key = ''): string
{
    if ($expenseId) {
        return url_path('admin/nfe-visualizar.php?id=' . rawurlencode($expenseId));
    }
    $digits = only_digits($key);
    return url_path('admin/nfe-visualizar.php?chave=' . rawurlencode($digits));
}

/** Link direto no ConsultaDANFE (útil para abrir em nova aba). */
function nfe_consultadanfe_url(string $key): string
{
    $digits = only_digits($key);
    if (!nfe_has_access_key($digits)) {
        return '#';
    }
    return 'https://consultadanfe.com/?chave=' . rawurlencode($digits);
}

function money_br(float|int|string|null $value): string
{
    return 'R$ ' . number_format((float) $value, 2, ',', '.');
}

function percent_br(float $ratio, int $decimals = 1): string
{
    return number_format($ratio * 100, $decimals, ',', '.') . '%';
}

function date_br(?string $value): string
{
    if (!$value) {
        return '—';
    }
    $ts = strtotime($value);
    return $ts ? date('d/m/Y', $ts) : $value;
}

function datetime_br(?string $value): string
{
    if (!$value) {
        return '—';
    }
    $ts = strtotime($value);
    return $ts ? date('d/m/Y H:i', $ts) : $value;
}

function app_base_path(): string
{
    return rtrim((string) (env('APP_BASE', '') ?: ''), '/');
}

/** Detecta HTTPS atrás de proxy/cPanel/Cloudflare. */
function is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        return true;
    }
    if (isset($_SERVER['SERVER_PORT']) && (string) $_SERVER['SERVER_PORT'] === '443') {
        return true;
    }
    $fwd = strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''));
    return $fwd === 'https';
}

/**
 * Redireciona para caminho interno (respeita APP_BASE) ou URL absoluta.
 * Preferimos caminhos relativos ao host + APP_BASE para não quebrar sessão/cookie no cPanel.
 */
function redirect(string $path): never
{
    if (!str_starts_with($path, 'http://') && !str_starts_with($path, 'https://')) {
        $base = app_base_path();
        $path = $base . '/' . ltrim($path, '/');
        // Normaliza // → /
        $path = '/' . ltrim($path, '/');
    }
    if (!headers_sent()) {
        header('Location: ' . $path, true, 302);
    }
    exit;
}

function flash_set(string $type, string $message): void
{
    $_SESSION['_flash'] = ['type' => $type, 'message' => $message];
}

function flash_get(): ?array
{
    if (empty($_SESSION['_flash'])) {
        return null;
    }
    $f = $_SESSION['_flash'];
    unset($_SESSION['_flash']);
    return $f;
}

function request_method(): string
{
    return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
}

function post(string $key, mixed $default = null): mixed
{
    return $_POST[$key] ?? $default;
}

function get(string $key, mixed $default = null): mixed
{
    return $_GET[$key] ?? $default;
}

function json_response(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function now_sql(): string
{
    return date('Y-m-d H:i:s');
}

function parse_date_input(?string $value): string
{
    if (!$value) {
        return date('Y-m-d H:i:s');
    }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return $value . ' 12:00:00';
    }
    $ts = strtotime($value);
    return $ts ? date('Y-m-d H:i:s', $ts) : date('Y-m-d H:i:s');
}

function asset(string $path): string
{
    $base = app_base_path();
    return ($base === '' ? '' : $base) . '/' . ltrim($path, '/');
}

function url_path(string $path): string
{
    $base = app_base_path();
    return ($base === '' ? '' : $base) . '/' . ltrim($path, '/');
}

/** Home autenticada — sempre aponta para o arquivo, evita 403 em /admin/ com Options -Indexes. */
function admin_home_path(): string
{
    return url_path('admin/index.php');
}
