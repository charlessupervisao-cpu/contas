<?php
declare(strict_types=1);

final class Metrics
{
    public static function getCampaign(): ?array
    {
        $pdo = Database::pdo();
        $campaign = $pdo->query('SELECT * FROM `Campaign` ORDER BY createdAt ASC LIMIT 1')->fetch();
        if (!$campaign) {
            return null;
        }
        $stmt = $pdo->prepare(
            'SELECT * FROM `BankAccount` WHERE campaignId = ? AND active = 1 ORDER BY sortOrder ASC, label ASC'
        );
        $stmt->execute([$campaign['id']]);
        $campaign['bankAccounts'] = $stmt->fetchAll();
        return $campaign;
    }

    public static function getDashboardMetrics(): ?array
    {
        $campaign = self::getCampaign();
        if (!$campaign) {
            return null;
        }
        $pdo = Database::pdo();
        $cid = $campaign['id'];

        $revenues = $pdo->prepare('SELECT * FROM `Revenue` WHERE campaignId = ?');
        $revenues->execute([$cid]);
        $revenues = $revenues->fetchAll();

        $expenses = $pdo->prepare("SELECT * FROM `Expense` WHERE campaignId = ? AND status <> 'CANCELADA'");
        $expenses->execute([$cid]);
        $expenses = $expenses->fetchAll();

        $cStmt = $pdo->prepare('SELECT COUNT(*) AS c FROM `CaboEleitoral` WHERE campaignId = ? AND active = 1');
        $cStmt->execute([$cid]);
        $cabos = (int) $cStmt->fetch()['c'];

        $contracts = (int) $pdo->query("SELECT COUNT(*) AS c FROM `Contract` WHERE status = 'ATIVO'")->fetch()['c'];

        $txStmt = $pdo->prepare(
            'SELECT t.* FROM `BankTransaction` t
             INNER JOIN `BankAccount` a ON a.id = t.bankAccountId
             WHERE a.campaignId = ?'
        );
        $txStmt->execute([$cid]);
        $transactions = $txStmt->fetchAll();

        $totalReceitas = array_sum(array_column($revenues, 'amount'));
        $totalDespesas = array_sum(array_column($expenses, 'amount'));
        $saldo = $totalReceitas - $totalDespesas;
        $budget = (float) $campaign['totalBudget'];

        $receitasPorFonte = [];
        foreach (REVENUE_SOURCES as $source => $label) {
            $items = array_values(array_filter($revenues, fn ($r) => $r['source'] === $source));
            $receitasPorFonte[] = [
                'source' => $source,
                'label' => $label,
                'amount' => array_sum(array_column($items, 'amount')),
                'count' => count($items),
            ];
        }

        $despesasPorCategoria = [];
        foreach (EXPENSE_CATEGORIES as $category => $label) {
            $items = array_values(array_filter($expenses, fn ($e) => $e['category'] === $category));
            $despesasPorCategoria[] = [
                'category' => $category,
                'label' => $label,
                'amount' => array_sum(array_column($items, 'amount')),
                'count' => count($items),
                'color' => EXPENSE_CATEGORY_COLORS[$category] ?? '#0f766e',
            ];
        }

        $vehicleFuelAmount = 0.0;
        foreach ($expenses as $e) {
            if ($e['category'] === 'VEICULOS' || $e['category'] === 'COMBUSTIVEIS') {
                $vehicleFuelAmount += (float) $e['amount'];
            }
        }
        $vehicleFuelLimit = $budget * VEHICLE_FUEL_LIMIT_RATIO;

        $nfeValid = count(array_filter($expenses, fn ($e) => (int) $e['nfeValid'] === 1));
        $nfeInvalid = count(array_filter($expenses, fn ($e) => $e['nfeKey'] && !(int) $e['nfeValid']));
        $nfeMissing = count(array_filter($expenses, fn ($e) => !$e['nfeKey']));

        $conciliated = count(array_filter($transactions, fn ($t) => $t['status'] === 'CONCILIADO'));
        $pending = count(array_filter($transactions, fn ($t) => $t['status'] === 'PENDENTE'));
        $divergent = count(array_filter($transactions, fn ($t) => $t['status'] === 'DIVERGENTE'));

        $donors = [];
        foreach ($revenues as $r) {
            if ($r['source'] === 'DOADOR_PF' && $r['donorCpf']) {
                $donors[$r['donorCpf']] = true;
            }
        }

        $bankBalances = array_map(static fn ($a) => [
            'id' => $a['id'],
            'label' => $a['label'],
            'bankName' => $a['bankName'],
            'balance' => (float) $a['balance'],
            'agency' => $a['agency'],
            'accountNumber' => $a['accountNumber'],
        ], $campaign['bankAccounts']);

        return [
            'campaign' => $campaign,
            'totals' => [
                'totalReceitas' => $totalReceitas,
                'totalDespesas' => $totalDespesas,
                'saldo' => $saldo,
                'orcamento' => $budget,
                'limiteLegal' => (float) $campaign['legalSpendLimit'],
                'percentualGasto' => $budget > 0 ? $totalDespesas / $budget : 0,
                'percentualRecebido' => $budget > 0 ? $totalReceitas / $budget : 0,
            ],
            'counts' => [
                'receitas' => count($revenues),
                'despesas' => count($expenses),
                'cabos' => $cabos,
                'contratosAtivos' => $contracts,
                'doadores' => count($donors),
                'contas' => count($campaign['bankAccounts']),
                'nfeValid' => $nfeValid,
                'nfeInvalid' => $nfeInvalid,
                'nfeMissing' => $nfeMissing,
                'conciliated' => $conciliated,
                'pending' => $pending,
                'divergent' => $divergent,
            ],
            'receitasPorFonte' => self::withShare($receitasPorFonte, $totalReceitas),
            'despesasPorCategoria' => self::withShare($despesasPorCategoria, $totalDespesas),
            'rankingDespesas' => self::rankByAmount($despesasPorCategoria, $totalDespesas),
            'vehicleFuel' => [
                'amount' => $vehicleFuelAmount,
                'limit' => $vehicleFuelLimit,
                'ratio' => $budget > 0 ? $vehicleFuelAmount / $budget : 0,
                'remaining' => max(0, $vehicleFuelLimit - $vehicleFuelAmount),
                'withinLimit' => $vehicleFuelAmount <= $vehicleFuelLimit,
            ],
            'bankBalances' => $bankBalances,
        ];
    }

    /** Últimas movimentações (entradas + saídas) para o painel financeiro. */
    public static function getRecentMovements(int $limit = 12): array
    {
        $pdo = Database::pdo();
        $campaign = self::getCampaign();
        if (!$campaign) {
            return [];
        }
        $cid = $campaign['id'];

        $sql = "
            (SELECT r.id, r.date AS movDate, r.createdAt, 'ENTRADA' AS kind, r.source AS code,
                    r.description AS detail, r.donorName AS party, r.amount, a.label AS accountLabel
             FROM `Revenue` r
             LEFT JOIN `BankAccount` a ON a.id = r.bankAccountId
             WHERE r.campaignId = ?)
            UNION ALL
            (SELECT e.id, e.date AS movDate, e.createdAt, 'SAIDA' AS kind, e.category AS code,
                    e.description AS detail, e.supplierName AS party, e.amount, a.label AS accountLabel
             FROM `Expense` e
             LEFT JOIN `BankAccount` a ON a.id = e.bankAccountId
             WHERE e.campaignId = ? AND e.status <> 'CANCELADA')
            ORDER BY movDate DESC, createdAt DESC
            LIMIT " . (int) $limit;

        $st = $pdo->prepare($sql);
        $st->execute([$cid, $cid]);
        return $st->fetchAll();
    }

    /** Fluxo de caixa mensal (entradas x saídas) — últimos N meses. */
    public static function getMonthlyCashFlow(int $months = 6): array
    {
        $pdo = Database::pdo();
        $campaign = self::getCampaign();
        if (!$campaign) {
            return [];
        }
        $cid = $campaign['id'];
        $rows = [];
        for ($i = $months - 1; $i >= 0; $i--) {
            $start = date('Y-m-01 00:00:00', strtotime("-{$i} months"));
            $end = date('Y-m-t 23:59:59', strtotime("-{$i} months"));
            $label = date('m/Y', strtotime($start));

            $in = $pdo->prepare('SELECT COALESCE(SUM(amount),0) AS t FROM `Revenue` WHERE campaignId=? AND date BETWEEN ? AND ?');
            $in->execute([$cid, $start, $end]);
            $out = $pdo->prepare("SELECT COALESCE(SUM(amount),0) AS t FROM `Expense` WHERE campaignId=? AND status<>'CANCELADA' AND date BETWEEN ? AND ?");
            $out->execute([$cid, $start, $end]);

            $entrada = (float) $in->fetch()['t'];
            $saida = (float) $out->fetch()['t'];
            $rows[] = [
                'label' => $label,
                'entrada' => $entrada,
                'saida' => $saida,
                'saldo' => $entrada - $saida,
            ];
        }
        return $rows;
    }

    public static function getDailyActivity(?string $date = null): array
    {
        $day = $date ?: date('Y-m-d');
        $start = $day . ' 00:00:00';
        $end = $day . ' 23:59:59';
        $pdo = Database::pdo();

        $logs = $pdo->prepare(
            "SELECT l.*, u.name AS userName, u.email AS userEmail
             FROM `AuditLog` l
             LEFT JOIN `User` u ON u.id = l.userId
             WHERE l.createdAt BETWEEN ? AND ?
               AND l.action IN ('LAUNCH','CREATE','BALANCE_ADJUST','RECONCILE','UPDATE')
             ORDER BY l.createdAt DESC"
        );
        $logs->execute([$start, $end]);
        $logs = $logs->fetchAll();

        $revenues = $pdo->prepare(
            'SELECT r.*, a.label AS accountLabel FROM `Revenue` r
             LEFT JOIN `BankAccount` a ON a.id = r.bankAccountId
             WHERE r.date BETWEEN ? AND ? ORDER BY r.createdAt DESC'
        );
        $revenues->execute([$start, $end]);
        $revenues = $revenues->fetchAll();

        $expenses = $pdo->prepare(
            "SELECT e.*, a.label AS accountLabel FROM `Expense` e
             LEFT JOIN `BankAccount` a ON a.id = e.bankAccountId
             WHERE e.date BETWEEN ? AND ? AND e.status <> 'CANCELADA'
             ORDER BY e.createdAt DESC"
        );
        $expenses->execute([$start, $end]);
        $expenses = $expenses->fetchAll();

        $adjustments = $pdo->prepare(
            'SELECT b.*, a.label AS accountLabel FROM `BalanceAdjustment` b
             LEFT JOIN `BankAccount` a ON a.id = b.bankAccountId
             WHERE b.date BETWEEN ? AND ? ORDER BY b.createdAt DESC'
        );
        $adjustments->execute([$start, $end]);
        $adjustments = $adjustments->fetchAll();

        $pending = $pdo->prepare(
            "SELECT COUNT(*) AS c FROM `BankTransaction` WHERE date BETWEEN ? AND ? AND status = 'PENDENTE'"
        );
        $pending->execute([$start, $end]);
        $pendingTx = (int) $pending->fetch()['c'];

        $totalIn = array_sum(array_column($revenues, 'amount'));
        $totalOut = array_sum(array_column($expenses, 'amount'));

        return [
            'date' => $day,
            'summary' => [
                'receitas' => count($revenues),
                'despesas' => count($expenses),
                'ajustes' => count($adjustments),
                'pendentesConciliacao' => $pendingTx,
                'totalIn' => $totalIn,
                'totalOut' => $totalOut,
                'saldoDia' => $totalIn - $totalOut,
                'eventos' => count($logs),
            ],
            'logs' => $logs,
            'revenues' => $revenues,
            'expenses' => $expenses,
            'adjustments' => $adjustments,
        ];
    }

    /** @param list<array<string,mixed>> $rows */
    private static function withShare(array $rows, float $total): array
    {
        return array_map(static function (array $row) use ($total) {
            $amount = (float) ($row['amount'] ?? 0);
            $row['share'] = $total > 0 ? $amount / $total : 0;
            return $row;
        }, $rows);
    }

    /**
     * Ranking de despesas por valor (maior → menor), com posição e %.
     * @param list<array<string,mixed>> $rows
     * @return list<array<string,mixed>>
     */
    public static function rankByAmount(array $rows, float $total): array
    {
        $rows = array_values(array_filter($rows, static fn ($r) => (float) ($r['amount'] ?? 0) > 0));
        usort($rows, static fn ($a, $b) => (float) $b['amount'] <=> (float) $a['amount']);
        $rank = 1;
        foreach ($rows as &$row) {
            $row['rank'] = $rank++;
            $row['share'] = $total > 0 ? ((float) $row['amount'] / $total) : 0;
        }
        unset($row);
        return $rows;
    }
}
