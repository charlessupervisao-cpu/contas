<?php
declare(strict_types=1);

const APP_NAME = 'POLLICONTAS';
const ELECTION_YEAR = 2026;
const APP_DOMAIN = 'pollicontas.synetiq.com.br';
const VEHICLE_FUEL_LIMIT_RATIO = 0.2;
const MAX_BANK_ACCOUNTS = 4;

const ROLES = [
    'MASTER' => 'MASTER',
    'FINANCEIRO' => 'FINANCEIRO',
    'RH' => 'RH',
    'CONSULTA' => 'CONSULTA',
];

const ROLE_LABELS = [
    'MASTER' => 'Master',
    'FINANCEIRO' => 'Financeiro (leitura)',
    'RH' => 'RH (leitura)',
    'CONSULTA' => 'Consulta (leitura)',
];

const EXPENSE_CATEGORIES = [
    'COMITE' => 'Comitê',
    'GRAFICA' => 'Gráfica',
    'INTERNET' => 'Internet',
    'VEICULOS' => 'Veículos',
    'IMPULSIONAMENTO' => 'Impulsionamento',
    'COMBUSTIVEIS' => 'Combustíveis',
    'CABOS_ELEITORAIS' => 'Cabos Eleitorais',
    'COMUNICACAO' => 'Comunicação',
];

const EXPENSE_CATEGORY_COLORS = [
    'COMITE' => '#0D9488',
    'GRAFICA' => '#0284C7',
    'INTERNET' => '#4F46E5',
    'VEICULOS' => '#EA580C',
    'IMPULSIONAMENTO' => '#DB2777',
    'COMBUSTIVEIS' => '#CA8A04',
    'CABOS_ELEITORAIS' => '#16A34A',
    'COMUNICACAO' => '#0891B2',
];

const REVENUE_SOURCES = [
    'DOADOR_PF' => 'Doador Pessoa Física',
    'FUNDO_PARTIDARIO' => 'Fundo Partidário',
    'VAQUINHA_ELEITORAL' => 'Vaquinha Eleitoral',
];

const REVENUE_SOURCE_COLORS = [
    'DOADOR_PF' => '#0D9488',
    'FUNDO_PARTIDARIO' => '#0284C7',
    'VAQUINHA_ELEITORAL' => '#CA8A04',
];

/**
 * Menu: group=dados (já lançados / consulta) | config (cadastros e ajustes).
 * Configuração fica fora da home e agrupada no rodapé do menu lateral.
 */
const MODULES = [
    ['id' => 'dashboard', 'label' => 'Dashboard', 'href' => '/admin/index.php', 'roles' => ['MASTER', 'FINANCEIRO', 'RH', 'CONSULTA'], 'group' => 'dados'],
    ['id' => 'movimentacoes', 'label' => 'Movimentações', 'href' => '/admin/movimentacoes.php', 'roles' => ['MASTER', 'FINANCEIRO', 'CONSULTA'], 'group' => 'dados'],
    ['id' => 'diario', 'label' => 'Diário do dia', 'href' => '/admin/diario.php', 'roles' => ['MASTER', 'FINANCEIRO', 'RH', 'CONSULTA'], 'group' => 'dados'],
    ['id' => 'receitas', 'label' => 'Receitas', 'href' => '/admin/receitas.php', 'roles' => ['MASTER', 'FINANCEIRO', 'CONSULTA'], 'group' => 'dados'],
    ['id' => 'despesas', 'label' => 'Despesas / NF-e', 'href' => '/admin/despesas.php', 'roles' => ['MASTER', 'FINANCEIRO', 'CONSULTA'], 'group' => 'dados'],
    ['id' => 'contas', 'label' => 'Contas bancárias', 'href' => '/admin/contas.php', 'roles' => ['MASTER', 'FINANCEIRO', 'CONSULTA'], 'group' => 'dados'],
    ['id' => 'conciliacao', 'label' => 'Conciliação', 'href' => '/admin/conciliacao.php', 'roles' => ['MASTER', 'FINANCEIRO'], 'group' => 'dados'],
    ['id' => 'fornecedores', 'label' => 'Fornecedores', 'href' => '/admin/fornecedores.php', 'roles' => ['MASTER', 'FINANCEIRO', 'CONSULTA'], 'group' => 'dados'],
    ['id' => 'veiculos', 'label' => 'Veículos', 'href' => '/admin/veiculos.php', 'roles' => ['MASTER', 'FINANCEIRO', 'CONSULTA'], 'group' => 'dados'],
    ['id' => 'cabos', 'label' => 'Cabos / Contratos', 'href' => '/admin/cabos.php', 'roles' => ['MASTER', 'RH', 'CONSULTA'], 'group' => 'dados'],
    ['id' => 'lancamento', 'label' => 'Novo lançamento', 'href' => '/admin/lancamento.php', 'roles' => ['MASTER'], 'group' => 'config'],
    ['id' => 'vinculos', 'label' => 'Vínculos conta', 'href' => '/admin/vinculos.php', 'roles' => ['MASTER', 'FINANCEIRO'], 'group' => 'config'],
    ['id' => 'saldos', 'label' => 'Ajuste de saldos', 'href' => '/admin/saldos.php', 'roles' => ['MASTER', 'FINANCEIRO'], 'group' => 'config'],
    ['id' => 'wizard', 'label' => 'Campanha / foto', 'href' => '/admin/wizard.php', 'roles' => ['MASTER'], 'group' => 'config'],
    ['id' => 'usuarios', 'label' => 'Usuários / perfis', 'href' => '/admin/usuarios.php', 'roles' => ['MASTER'], 'group' => 'config'],
];

const VIEW_ROLES = [
    'dashboard' => ['MASTER', 'FINANCEIRO', 'RH', 'CONSULTA'],
    'movimentacoes' => ['MASTER', 'FINANCEIRO', 'CONSULTA'],
    'receitas' => ['MASTER', 'FINANCEIRO', 'CONSULTA'],
    'despesas' => ['MASTER', 'FINANCEIRO', 'CONSULTA'],
    'cabos' => ['MASTER', 'RH', 'CONSULTA'],
    'contas' => ['MASTER', 'FINANCEIRO', 'CONSULTA'],
    'conciliacao' => ['MASTER', 'FINANCEIRO'],
    'veiculos' => ['MASTER', 'FINANCEIRO', 'CONSULTA'],
    'fornecedores' => ['MASTER', 'FINANCEIRO', 'CONSULTA'],
    'saldos' => ['MASTER', 'FINANCEIRO'],
    'lancamento' => ['MASTER', 'FINANCEIRO', 'CONSULTA'],
    'vinculos' => ['MASTER', 'FINANCEIRO'],
    'diario' => ['MASTER', 'FINANCEIRO', 'RH', 'CONSULTA'],
    'usuarios' => ['MASTER'],
    'wizard' => ['MASTER'],
];

/** Cargo padrão da campanha (GO 2026 — reeleição) */
const DEFAULT_OFFICE = 'Deputado Estadual';
const DEFAULT_STATE = 'GO';

/**
 * Referência DivulgaCandContas (prestação 2022 — Virmondes Cruvinel).
 * Usada para sincronizar fornecedores / NF-es.
 */
const TSE_DIVULGA_CANDIDATO = [
    'sqEleicao' => '2040602022',
    'ano' => '2022',
    'sgUe' => 'GO',
    'regiao' => 'CENTROOESTE',
    'cargo' => '7',
    'nrPartido' => '44',
    'nrCandidato' => '44321',
    'idCandidato' => '90001648401',
    'urlNfes' => 'https://divulgacandcontas.tse.jus.br/divulga/#/candidato/CENTROOESTE/GO/2040602022/90001648401/2022/GO/nfes',
];

/** Perfis e permissões de lançamento */
const PROFILE_MATRIX = [
    'MASTER' => [
        'label' => 'Master',
        'description' => 'Acesso total. Único perfil que altera e lança dados.',
        'canLaunch' => true,
    ],
    'FINANCEIRO' => [
        'label' => 'Financeiro',
        'description' => 'Acessa receitas, despesas, contas e conciliação — sem alterar.',
        'canLaunch' => false,
    ],
    'RH' => [
        'label' => 'Recursos Humanos',
        'description' => 'Acessa cabos e contratos — sem cadastrar ou alterar.',
        'canLaunch' => false,
    ],
    'CONSULTA' => [
        'label' => 'Consulta',
        'description' => 'Somente leitura dos painéis e listagens (não altera nada).',
        'canLaunch' => false,
    ],
];

/**
 * Atalhos numéricos (dashboard) e F-keys para cada situação de lançamento/consulta.
 * Teclas 1–9 no dashboard; F2–F8 em qualquer tela do admin.
 */
const QUICK_ACCESS = [
    ['key' => '1', 'label' => 'Lançamento (F3)', 'href' => '/admin/lancamento.php', 'roles' => ['MASTER'], 'launch' => true, 'hint' => 'Entrar dados'],
    ['key' => '2', 'label' => 'Entrada / Receita (F2)', 'href' => '/admin/lancamento.php?tipo=RECEITA', 'roles' => ['MASTER'], 'launch' => true, 'hint' => 'Registrar entrada'],
    ['key' => '3', 'label' => 'Saída / Despesa (F4)', 'href' => '/admin/lancamento.php?tipo=DESPESA', 'roles' => ['MASTER'], 'launch' => true, 'hint' => 'Registrar saída'],
    ['key' => '4', 'label' => 'Movimentações', 'href' => '/admin/movimentacoes.php', 'roles' => ['MASTER', 'FINANCEIRO', 'CONSULTA'], 'launch' => false, 'hint' => 'Todas as entradas e saídas'],
    ['key' => '5', 'label' => 'Diário do dia (F6)', 'href' => '/admin/diario.php', 'roles' => ['MASTER', 'FINANCEIRO', 'CONSULTA'], 'launch' => false, 'hint' => 'Atividade do dia'],
    ['key' => '6', 'label' => 'Vínculos conta (F7)', 'href' => '/admin/vinculos.php', 'roles' => ['MASTER'], 'launch' => true, 'hint' => 'Categoria → conta'],
    ['key' => '7', 'label' => 'Ajuste de Saldos', 'href' => '/admin/saldos.php', 'roles' => ['MASTER'], 'launch' => true, 'hint' => 'Saldo bancário'],
    ['key' => '8', 'label' => 'Conciliação (F8)', 'href' => '/admin/conciliacao.php', 'roles' => ['MASTER', 'FINANCEIRO'], 'launch' => false, 'hint' => 'Até 4 contas'],
    ['key' => '9', 'label' => 'Cabo + Contrato', 'href' => '/admin/cabos/novo.php', 'roles' => ['MASTER'], 'launch' => true, 'hint' => 'Cadastrar cabo'],
];
