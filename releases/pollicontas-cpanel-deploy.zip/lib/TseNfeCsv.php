<?php

declare(strict_types=1);

/**
 * Importa o CSV exportado da aba NF-es do DivulgaCandContas.
 * Colunas: CNPJ Emitente, Nome do Emitente, Natureza Op., Modelo, Data Emissão,
 * Nº NF, Nº Série, Valor, UE, Unidade Arrecadadora, Ue, Chave, Link.
 */
final class TseNfeCsv
{
    public const DEFAULT_CSV = __DIR__ . '/../data/tse-nfes-2022.csv';

    /**
     * Apaga fornecedores + NF-es da campanha e importa o CSV completo.
     *
     * @return array{deletedSuppliers:int,deletedNfes:int,suppliers:int,nfes:int,error?:string}
     */
    public static function replaceFromCsv(string $campaignId, ?string $csvPath = null): array
    {
        $csvPath = $csvPath ?: self::DEFAULT_CSV;
        if (!is_file($csvPath)) {
            return [
                'deletedSuppliers' => 0,
                'deletedNfes' => 0,
                'suppliers' => 0,
                'nfes' => 0,
                'error' => 'Arquivo CSV não encontrado: ' . $csvPath,
            ];
        }

        $parsed = self::parseCsv($csvPath);
        if (!$parsed['ok']) {
            return [
                'deletedSuppliers' => 0,
                'deletedNfes' => 0,
                'suppliers' => 0,
                'nfes' => 0,
                'error' => $parsed['error'] ?? 'CSV inválido.',
            ];
        }

        $pdo = Database::pdo();
        $now = now_sql();
        $pdo->beginTransaction();
        try {
            $pdo->prepare('UPDATE `Expense` SET supplierId = NULL WHERE campaignId = ?')->execute([$campaignId]);

            if (self::tableExists($pdo, 'SupplierNfe')) {
                $delNfe = $pdo->prepare('DELETE FROM `SupplierNfe` WHERE campaignId = ?');
                $delNfe->execute([$campaignId]);
                $deletedNfes = $delNfe->rowCount();
            } else {
                $deletedNfes = 0;
            }

            $delSup = $pdo->prepare('DELETE FROM `Supplier` WHERE campaignId = ?');
            $delSup->execute([$campaignId]);
            $deletedSuppliers = $delSup->rowCount();

            $supplierMap = self::insertSuppliers($pdo, $campaignId, $parsed['emitentes'], $now);
            $nfeCount = self::insertNfes($pdo, $campaignId, $parsed['rows'], $supplierMap, $now);

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            return [
                'deletedSuppliers' => 0,
                'deletedNfes' => 0,
                'suppliers' => 0,
                'nfes' => 0,
                'error' => $e->getMessage(),
            ];
        }

        return [
            'deletedSuppliers' => $deletedSuppliers,
            'deletedNfes' => $deletedNfes,
            'suppliers' => count($supplierMap),
            'nfes' => $nfeCount,
        ];
    }

    /**
     * @return array{ok:bool,rows?:list<array>,emitentes?:array<string,array>,error?:string}
     */
    public static function parseCsv(string $path): array
    {
        $fh = fopen($path, 'rb');
        if (!$fh) {
            return ['ok' => false, 'error' => 'Não foi possível abrir o CSV.'];
        }

        $header = fgetcsv($fh);
        if (!$header) {
            fclose($fh);
            return ['ok' => false, 'error' => 'CSV sem cabeçalho.'];
        }
        $header = array_map(static fn ($h) => trim((string) $h), $header);

        $map = [
            'cnpjEmitente' => ['CNPJ Emitente', 'cnpjEmitente'],
            'nmEmitente' => ['Nome do Emitente', 'nmEmitente'],
            'naturezaOp' => ['Natureza Op.', 'Natureza Op', 'naturezaOp'],
            'modelo' => ['Modelo', 'modelo'],
            'dataEmissao' => ['Data Emissão', 'Data Emissao', 'dataEmissao'],
            'numeroNf' => ['Nº NF', 'No NF', 'N° NF', 'numeroNf'],
            'numeroSerie' => ['Nº Série', 'Nº Serie', 'No Série', 'numeroSerie'],
            'valor' => ['Valor', 'valor'],
            'ue' => ['UE', 'ue'],
            'unidadeArrecadadora' => ['Unidade Arrecadadora', 'unidadeArrecadadora'],
            'dsUe' => ['Ue', 'dsUe'],
            'chaveAcesso' => ['Chave', 'chaveAcesso', 'chave'],
            'link' => ['Link', 'link'],
        ];
        $idx = [];
        foreach ($map as $key => $aliases) {
            foreach ($aliases as $alias) {
                $pos = array_search($alias, $header, true);
                if ($pos !== false) {
                    $idx[$key] = $pos;
                    break;
                }
            }
        }
        if (!isset($idx['cnpjEmitente'], $idx['nmEmitente'])) {
            fclose($fh);
            return ['ok' => false, 'error' => 'CSV sem colunas CNPJ Emitente / Nome do Emitente.'];
        }

        $rows = [];
        $emitentes = [];
        while (($cols = fgetcsv($fh)) !== false) {
            if (count($cols) === 1 && trim((string) $cols[0]) === '') {
                continue;
            }
            $get = static function (string $k) use ($cols, $idx): string {
                if (!isset($idx[$k])) {
                    return '';
                }
                return trim((string) ($cols[$idx[$k]] ?? ''));
            };

            $digits = only_digits($get('cnpjEmitente'));
            $name = $get('nmEmitente');
            if ($digits === '' || $name === '') {
                continue;
            }

            $valorRaw = str_replace(',', '.', $get('valor'));
            $valor = is_numeric($valorRaw) ? (float) $valorRaw : 0.0;
            $ue = strtoupper($get('ue'));
            $dsUe = $get('dsUe');
            $natureza = $get('naturezaOp');

            $row = [
                'cnpjEmitente' => $digits,
                'nmEmitente' => $name,
                'naturezaOp' => $natureza !== '' ? $natureza : null,
                'modelo' => ($m = $get('modelo')) !== '' ? $m : null,
                'dataEmissao' => self::parseBrDate($get('dataEmissao')),
                'numeroNf' => ($n = $get('numeroNf')) !== '' ? $n : null,
                'numeroSerie' => ($s = trim($get('numeroSerie'))) !== '' ? $s : null,
                'valor' => $valor,
                'ue' => $ue !== '' ? $ue : null,
                'unidadeArrecadadora' => ($u = $get('unidadeArrecadadora')) !== '' ? $u : null,
                'dsUe' => $dsUe !== '' ? $dsUe : null,
                'chaveAcesso' => ($c = $get('chaveAcesso')) !== '' ? $c : null,
                'link' => ($l = $get('link')) !== '' ? $l : null,
            ];
            $rows[] = $row;

            // Prefixo "d:" evita que PHP converta CNPJ com zeros à esquerda em int
            $ek = 'd:' . $digits;
            if (!isset($emitentes[$ek])) {
                $emitentes[$ek] = [
                    'document' => $digits,
                    'name' => $name,
                    'city' => ($dsUe !== '' && $ue !== 'BR') ? $dsUe : null,
                    'state' => ($ue !== '' && $ue !== 'BR') ? $ue : null,
                    'category' => $natureza !== '' ? $natureza : null,
                    'qtd' => 0,
                    'valor' => 0.0,
                ];
            }
            $emitentes[$ek]['qtd']++;
            $emitentes[$ek]['valor'] += $valor;
            // Prefere município/UF reais (GO/SP) em vez de BR/BRASIL do espelho RFB
            if ($ue !== '' && $ue !== 'BR') {
                $emitentes[$ek]['state'] = $ue;
                if ($dsUe !== '') {
                    $emitentes[$ek]['city'] = $dsUe;
                }
            }
            if ($natureza !== '' && empty($emitentes[$ek]['category'])) {
                $emitentes[$ek]['category'] = $natureza;
            }
            $emitentes[$ek]['name'] = $name;
        }
        fclose($fh);

        if (!$rows) {
            return ['ok' => false, 'error' => 'CSV sem linhas de NF-e.'];
        }

        return ['ok' => true, 'rows' => $rows, 'emitentes' => $emitentes];
    }

    /** @param array<string,array> $emitentes @return array<string,string> */
    private static function insertSuppliers(PDO $pdo, string $campaignId, array $emitentes, string $now): array
    {
        $ins = $pdo->prepare(
            'INSERT INTO `Supplier` (
                id, campaignId, name, tradeName, documentType, document, email, phone, contactName,
                zipCode, address, addressNumber, addressComplement, neighborhood, city, state,
                stateRegistration, municipalRegistration, category, notes, active, createdAt, updatedAt
             ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)'
        );
        $map = [];
        foreach ($emitentes as $e) {
            $digits = (string) $e['document'];
            $id = cuid();
            $docType = document_type_from_digits($digits) ?? 'CNPJ';
            $document = format_cpf_cnpj($digits);
            $notes = sprintf(
                'Emitente NF-e DivulgaCandContas/TSE · %d nota(s) · R$ %s',
                (int) $e['qtd'],
                number_format((float) $e['valor'], 2, ',', '.')
            );
            $ins->execute([
                $id, $campaignId, $e['name'], null, $docType, $document,
                null, null, null, null, null, null, null, null,
                $e['city'], $e['state'], null, null, $e['category'], $notes, $now, $now,
            ]);
            $map['d:' . $digits] = $id;
        }
        return $map;
    }

    /**
     * @param list<array> $rows
     * @param array<string,string> $supplierMap
     */
    private static function insertNfes(PDO $pdo, string $campaignId, array $rows, array $supplierMap, string $now): int
    {
        $ins = $pdo->prepare(
            'INSERT INTO `SupplierNfe` (
                id, campaignId, supplierId, cnpjEmitente, nmEmitente, naturezaOp, modelo, dataEmissao,
                numeroNf, numeroSerie, valor, ue, unidadeArrecadadora, dsUe, chaveAcesso, link, createdAt, updatedAt
             ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        );
        $count = 0;
        foreach ($rows as $r) {
            $digits = (string) $r['cnpjEmitente'];
            $supplierId = $supplierMap['d:' . $digits] ?? null;
            $ins->execute([
                cuid(),
                $campaignId,
                $supplierId,
                format_cpf_cnpj($digits),
                $r['nmEmitente'],
                $r['naturezaOp'],
                $r['modelo'],
                $r['dataEmissao'],
                $r['numeroNf'],
                $r['numeroSerie'],
                $r['valor'],
                $r['ue'],
                $r['unidadeArrecadadora'],
                $r['dsUe'],
                $r['chaveAcesso'],
                $r['link'],
                $now,
                $now,
            ]);
            $count++;
        }
        return $count;
    }

    private static function parseBrDate(string $value): ?string
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }
        if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})$/', $value, $m)) {
            return $m[3] . '-' . $m[2] . '-' . $m[1];
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return $value;
        }
        $ts = strtotime($value);
        return $ts ? date('Y-m-d', $ts) : null;
    }

    private static function tableExists(PDO $pdo, string $table): bool
    {
        $st = $pdo->prepare(
            'SELECT COUNT(*) AS c FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?'
        );
        $st->execute([$table]);
        return (int) $st->fetch()['c'] > 0;
    }
}
