<?php
declare(strict_types=1);

/** Migrações leves para instalações já existentes (cPanel). */
final class Schema
{
    private static bool $ensured = false;

    public static function ensure(): void
    {
        if (self::$ensured) {
            return;
        }
        self::$ensured = true;

        try {
            $pdo = Database::pdo();
        } catch (Throwable) {
            return;
        }

        self::ensureSupplierColumns($pdo);
        self::ensureSupplierNfeTable($pdo);
    }

    private static function ensureSupplierColumns(PDO $pdo): void
    {
        $cols = [
            'tradeName' => 'VARCHAR(191) NULL',
            'documentType' => 'VARCHAR(191) NULL',
            'contactName' => 'VARCHAR(191) NULL',
            'zipCode' => 'VARCHAR(191) NULL',
            'addressNumber' => 'VARCHAR(191) NULL',
            'addressComplement' => 'VARCHAR(191) NULL',
            'neighborhood' => 'VARCHAR(191) NULL',
            'stateRegistration' => 'VARCHAR(191) NULL',
            'municipalRegistration' => 'VARCHAR(191) NULL',
        ];
        foreach ($cols as $name => $def) {
            if (!self::columnExists($pdo, 'Supplier', $name)) {
                $pdo->exec("ALTER TABLE `Supplier` ADD COLUMN `{$name}` {$def}");
            }
        }
        if (!self::indexExists($pdo, 'Supplier', 'Supplier_document_idx')) {
            try {
                $pdo->exec('ALTER TABLE `Supplier` ADD INDEX `Supplier_document_idx`(`document`)');
            } catch (Throwable) {
                // índice pode já existir com outro nome
            }
        }
    }

    private static function ensureSupplierNfeTable(PDO $pdo): void
    {
        if (self::tableExists($pdo, 'SupplierNfe')) {
            return;
        }
        $pdo->exec(
            "CREATE TABLE `SupplierNfe` (
                `id` VARCHAR(191) NOT NULL,
                `campaignId` VARCHAR(191) NOT NULL,
                `supplierId` VARCHAR(191) NULL,
                `cnpjEmitente` VARCHAR(191) NOT NULL,
                `nmEmitente` VARCHAR(191) NOT NULL,
                `naturezaOp` VARCHAR(191) NULL,
                `modelo` VARCHAR(191) NULL,
                `dataEmissao` DATE NULL,
                `numeroNf` VARCHAR(191) NULL,
                `numeroSerie` VARCHAR(191) NULL,
                `valor` DOUBLE NOT NULL DEFAULT 0,
                `ue` VARCHAR(191) NULL,
                `unidadeArrecadadora` VARCHAR(191) NULL,
                `dsUe` VARCHAR(191) NULL,
                `chaveAcesso` VARCHAR(191) NULL,
                `link` TEXT NULL,
                `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
                `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
                INDEX `SupplierNfe_campaignId_idx`(`campaignId`),
                INDEX `SupplierNfe_supplierId_idx`(`supplierId`),
                INDEX `SupplierNfe_cnpjEmitente_idx`(`cnpjEmitente`),
                INDEX `SupplierNfe_chaveAcesso_idx`(`chaveAcesso`),
                PRIMARY KEY (`id`)
            ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        );
        try {
            $pdo->exec(
                'ALTER TABLE `SupplierNfe`
                 ADD CONSTRAINT `SupplierNfe_campaignId_fkey`
                 FOREIGN KEY (`campaignId`) REFERENCES `Campaign`(`id`) ON DELETE CASCADE ON UPDATE CASCADE'
            );
        } catch (Throwable) {
        }
        try {
            $pdo->exec(
                'ALTER TABLE `SupplierNfe`
                 ADD CONSTRAINT `SupplierNfe_supplierId_fkey`
                 FOREIGN KEY (`supplierId`) REFERENCES `Supplier`(`id`) ON DELETE SET NULL ON UPDATE CASCADE'
            );
        } catch (Throwable) {
        }
    }

    private static function tableExists(PDO $pdo, string $table): bool
    {
        $st = $pdo->prepare(
            'SELECT COUNT(*) AS c FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?'
        );
        $st->execute([$table]);
        return (int) $st->fetch()['c'] > 0;
    }

    private static function columnExists(PDO $pdo, string $table, string $column): bool
    {
        $st = $pdo->prepare(
            'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?'
        );
        $st->execute([$table, $column]);
        return (int) $st->fetch()['c'] > 0;
    }

    private static function indexExists(PDO $pdo, string $table, string $index): bool
    {
        $st = $pdo->prepare(
            'SELECT COUNT(*) AS c FROM information_schema.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?'
        );
        $st->execute([$table, $index]);
        return (int) $st->fetch()['c'] > 0;
    }
}
