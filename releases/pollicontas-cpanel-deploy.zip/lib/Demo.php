<?php
declare(strict_types=1);

final class Demo
{
    public static function ensureDefaultUsers(): array
    {
        $pdo = Database::pdo();
        $hash = password_hash('admin123', PASSWORD_BCRYPT, ['cost' => 10]);
        $defs = [
            ['Master Campanha', 'master@pollicontas.synetiq.com.br', 'MASTER'],
            ['Tesoureiro', 'financeiro@pollicontas.synetiq.com.br', 'FINANCEIRO'],
            ['Coord. RH', 'rh@pollicontas.synetiq.com.br', 'RH'],
            ['Consulta (somente leitura)', 'consulta@pollicontas.synetiq.com.br', 'CONSULTA'],
        ];
        $now = now_sql();
        foreach ($defs as [$name, $email, $role]) {
            $sel = $pdo->prepare('SELECT id FROM `User` WHERE email = ? LIMIT 1');
            $sel->execute([$email]);
            $row = $sel->fetch();
            if ($row) {
                $pdo->prepare('UPDATE `User` SET name=?, role=?, active=1, passwordHash=?, updatedAt=? WHERE id=?')
                    ->execute([$name, $role, $hash, $now, $row['id']]);
            } else {
                $pdo->prepare(
                    'INSERT INTO `User` (id, name, email, passwordHash, role, active, createdAt, updatedAt) VALUES (?,?,?,?,?,1,?,?)'
                )->execute([cuid(), $name, $email, $hash, $role, $now, $now]);
            }
        }
        $stmt = $pdo->prepare('SELECT * FROM `User` WHERE email = ? LIMIT 1');
        $stmt->execute(['master@pollicontas.synetiq.com.br']);
        return $stmt->fetch();
    }

    public static function clearOperationalData(?string $userId = null): array
    {
        $pdo = Database::pdo();
        $campaign = $pdo->query('SELECT * FROM `Campaign` ORDER BY createdAt ASC LIMIT 1')->fetch() ?: null;

        $pdo->exec('DELETE FROM `AuditLog`');
        $pdo->exec('DELETE FROM `BalanceAdjustment`');
        $pdo->exec('DELETE FROM `BankTransaction`');
        $pdo->exec('DELETE FROM `Expense`');
        $pdo->exec('DELETE FROM `Revenue`');
        $pdo->exec('DELETE FROM `Contract`');
        $pdo->exec('DELETE FROM `CaboEleitoral`');
        $pdo->exec('DELETE FROM `Vehicle`');
        try {
            $pdo->exec('DELETE FROM `SupplierNfe`');
        } catch (Throwable) {
            // tabela pode ainda não existir em bases antigas
        }
        $pdo->exec('DELETE FROM `Supplier`');
        $pdo->exec('DELETE FROM `AccountMapping`');
        $pdo->exec('DELETE FROM `BankAccount`');

        $now = now_sql();
        if (!$campaign) {
            $id = cuid();
            $pdo->prepare(
                'INSERT INTO `Campaign` (id, electionYear, candidateName, candidateFullName, candidateNumber, party, partyNumber, cnpjCampaign, office, state, region, ballotName, situation, reelection, legalSpendLimit, totalBudget, birthDate, gender, education, occupation, nationality, website, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                $id, 2026, 'Virmondes Cruvinel', 'Virmondes Borges Cruvinel Filho', '44321',
                'UNIÃO', '44', '47552932000100', 'Deputado Estadual', 'GO', 'CENTROOESTE',
                'Virmondes Cruvinel', 'Em campanha — Prestação de contas 2026', 1,
                1400000, 1200000, '10/03/1980', 'Masculino', 'Superior Completo',
                'Advogado / Deputado Estadual', 'Brasileira Nata / GO-Goiânia',
                'https://virmondes.com.br', $now, $now,
            ]);
            $campaign = ['id' => $id];
        }

        $pdo->prepare(
            'INSERT INTO `AuditLog` (id, userId, action, entity, details, createdAt) VALUES (?,?,?,?,?,?)'
        )->execute([cuid(), $userId, 'CLEAR', 'SYSTEM', 'Dados operacionais limpos — pronto para abastecimento do zero', $now]);

        return ['campaignId' => $campaign['id']];
    }

    public static function loadDemoData(?string $actorUserId = null): array
    {
        $master = self::ensureDefaultUsers();
        self::clearOperationalData($actorUserId ?: $master['id']);
        $pdo = Database::pdo();
        $now = now_sql();

        $campaign = $pdo->query('SELECT * FROM `Campaign` ORDER BY createdAt ASC LIMIT 1')->fetch();
        $pdo->prepare(
            'UPDATE `Campaign` SET electionYear=?, candidateName=?, candidateFullName=?, candidateNumber=?, party=?, partyNumber=?, totalBudget=?, legalSpendLimit=?, situation=?, updatedAt=? WHERE id=?'
        )->execute([
            2026, 'Virmondes Cruvinel', 'Virmondes Borges Cruvinel Filho', '44321',
            'UNIÃO', '44', 1200000, 1400000, 'Em campanha — Prestação de contas 2026', $now, $campaign['id'],
        ]);

        $accountsDef = [
            ['Conta Principal', 'Banco do Brasil', '001', '3456-7', '12345-6', 285400, 0],
            ['Conta Fundo Partidário', 'Caixa Econômica Federal', '104', '1289', '98765-4', 180000, 1],
            ['Conta Vaquinha', 'Itaú Unibanco', '341', '4521', '55432-1', 62450, 2],
            ['Conta Operacional', 'Santander', '033', '2100', '77881-0', 41320, 3],
        ];
        $accounts = [];
        foreach ($accountsDef as $a) {
            $id = cuid();
            $pdo->prepare(
                'INSERT INTO `BankAccount` (id, campaignId, label, bankName, bankCode, agency, accountNumber, accountType, balance, active, sortOrder, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,1,?,?,?)'
            )->execute([$id, $campaign['id'], $a[0], $a[1], $a[2], $a[3], $a[4], 'Corrente', $a[5], $a[6], $now, $now]);
            $accounts[] = ['id' => $id, 'label' => $a[0]];
        }
        Lancamento::seedDefaultMappings($campaign['id'], array_column($accounts, 'id'));

        $revenues = [
            ['FUNDO_PARTIDARIO', 'Diretório Estadual UNIÃO-GO', 280000, '2026-07-05', 'Repasse fundo partidário — parcela 1', $accounts[1]['id'], null, null],
            ['FUNDO_PARTIDARIO', 'Diretório Estadual UNIÃO-GO', 120000, '2026-08-01', 'Repasse fundo partidário — parcela 2', $accounts[1]['id'], null, null],
            ['VAQUINHA_ELEITORAL', 'Financiamento Coletivo Oficial', 48500, '2026-07-20', 'Arrecadação vaquinha — ciclo 1', $accounts[2]['id'], null, null],
            ['VAQUINHA_ELEITORAL', 'Financiamento Coletivo Oficial', 31200, '2026-08-02', 'Arrecadação vaquinha — ciclo 2', $accounts[2]['id'], null, null],
        ];
        $donorNames = [
            'Ana Paula Mendes', 'Carlos Eduardo Silva', 'Fernanda Rocha Lima', 'José Roberto Alves',
            'Mariana Costa Nunes', 'Paulo Henrique Dias', 'Luciana Martins Souza', 'Ricardo Borges Pinto',
            'Juliana Ferreira', 'André Luiz Cardoso', 'Patrícia Gomes', 'Bruno Teixeira',
        ];
        foreach ($donorNames as $i => $name) {
            $day = str_pad((string) (8 + ($i % 20)), 2, '0', STR_PAD_LEFT);
            $revenues[] = [
                'DOADOR_PF', $name, 1500 + $i * 850, "2026-07-{$day}", 'Doação pessoa física',
                $accounts[0]['id'], generate_valid_cpf(1000 + $i), 'REC-2026-' . str_pad((string) ($i + 1), 4, '0', STR_PAD_LEFT),
            ];
        }

        $revenueIds = [];
        foreach ($revenues as $r) {
            $id = cuid();
            $revenueIds[] = $id;
            $pdo->prepare(
                'INSERT INTO `Revenue` (id, campaignId, source, donorName, donorCpf, amount, date, description, receiptNumber, bankAccountId, createdById, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                $id, $campaign['id'], $r[0], $r[1], $r[6], $r[2], $r[3] . ' 12:00:00', $r[4], $r[7], $r[5], $master['id'], $now, $now,
            ]);
        }

        $caboData = [
            ['Marcos Antônio Pereira', 'Goiânia', 'Zona Norte'],
            ['Sueli Aparecida Ramos', 'Aparecida de Goiânia', 'Centro'],
            ['Diego Fernandes Lima', 'Anápolis', 'Zona Sul'],
            ['Camila Rodrigues', 'Rio Verde', 'Centro'],
            ['Rafael Souza Melo', 'Catalão', 'Zona Leste'],
            ['Helena Cristina Dias', 'Itumbiara', 'Centro'],
            ['Gustavo Henrique Alves', 'Jataí', 'Zona Oeste'],
            ['Beatriz Oliveira', 'Luziânia', 'Centro'],
        ];
        $cabos = [];
        foreach ($caboData as $i => $c) {
            $id = cuid();
            $cabos[] = $id;
            $pdo->prepare(
                'INSERT INTO `CaboEleitoral` (id, campaignId, fullName, cpf, phone, email, address, city, state, zone, roleTitle, active, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,1,?,?)'
            )->execute([
                $id, $campaign['id'], $c[0], generate_valid_cpf(2000 + $i),
                sprintf('(62) 9%d-%d', 8000 + $i, 1000 + $i),
                'cabo' . ($i + 1) . '@campanha2026.go',
                'Rua das Palmeiras, ' . (100 + $i), $c[1], 'GO', $c[2], 'Cabo Eleitoral', $now, $now,
            ]);
            $monthly = 2200 + $i * 100;
            $pdo->prepare(
                'INSERT INTO `Contract` (id, caboId, contractNumber, startDate, endDate, monthlyValue, totalValue, functionDesc, status, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                cuid(), $id, 'CT-2026-' . str_pad((string) ($i + 1), 4, '0', STR_PAD_LEFT),
                '2026-07-01 00:00:00', '2026-10-05 00:00:00', $monthly, $monthly * 3,
                'Articulação territorial e mobilização eleitoral por prazo determinado.', 'ATIVO', $now, $now,
            ]);
        }

        $vehicles = [
            ['Van itinerância 01', 'QWE1A23', 'Renault', 'Master', '2022', 'Van', 'Branca', 'Locadora Rápida GO', 1],
            ['Carro coordenação', 'RTY2B45', 'Volkswagen', 'Virtus', '2023', 'Automóvel', 'Prata', 'Auto Loc Goiânia', 1],
            ['Motocicleta apoio', 'UIO3C67', 'Honda', 'CG 160', '2021', 'Motocicleta', 'Vermelha', null, 0],
        ];
        foreach ($vehicles as $v) {
            $pdo->prepare(
                'INSERT INTO `Vehicle` (id, campaignId, label, plate, brand, model, year, type, color, ownerName, active, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([cuid(), $campaign['id'], $v[0], $v[1], $v[2], $v[3], $v[4], $v[5], $v[6], $v[7], $v[8], $now, $now]);
        }

        // Fornecedores + NF-es do CSV oficial da aba NF-es (DivulgaCandContas)
        $csvImport = TseNfeCsv::replaceFromCsv((string) $campaign['id']);
        $supplierMap = [];
        $supRows = $pdo->prepare('SELECT id, document, name FROM `Supplier` WHERE campaignId = ?');
        $supRows->execute([$campaign['id']]);
        foreach ($supRows->fetchAll() as $s) {
            $supplierMap[only_digits((string) $s['document'])] = (string) $s['id'];
            $supplierMap[(string) $s['name']] = (string) $s['id'];
        }
        unset($csvImport);

        // Despesas demo vinculadas a prestadores reais do TSE (por CPF/CNPJ)
        $expenses = [
            ['GRAFICA', '00747303000172', 'Material gráfico — GRAFOPEL (ref. TSE 2022)', 42000, $accounts[0]['id']],
            ['VEICULOS', '32312128000187', 'Locação — SMART LOC (ref. TSE 2022)', 28000, $accounts[0]['id']],
            ['IMPULSIONAMENTO', '13347016000117', 'Impulsionamento Facebook / Meta (ref. TSE 2022)', 29465, $accounts[2]['id']],
            ['IMPULSIONAMENTO', '06990590000123', 'Google Ads / NFS-e (ref. TSE 2022)', 15500, $accounts[2]['id']],
            ['COMBUSTIVEIS', '01595271000108', 'Abastecimento — Posto Xodó (ref. TSE 2022)', 12400, $accounts[3]['id']],
            ['VEICULOS', '24095599000152', 'Locação — Premium Tur (ref. TSE 2022)', 9500, $accounts[0]['id']],
            ['COMUNICACAO', '47413717000129', 'Evento / música — Dreams (ref. TSE 2022)', 12000, $accounts[0]['id']],
            ['COMUNICACAO', '06273582000166', 'Produção — RS Produtos e Serviços (ref. TSE 2022)', 8000, $accounts[0]['id']],
            ['INTERNET', '14707720000104', 'Comunicação visual — Conexão Digital (ref. TSE 2022)', 3200, $accounts[3]['id']],
            ['GRAFICA', '14647750000164', 'Confecção / malharia — TZ (ref. TSE 2022)', 16420, $accounts[0]['id']],
            ['COMITE', '01732140000117', 'Auditoria e consultoria — MW (ref. TSE 2022)', 13910, $accounts[0]['id']],
            ['COMBUSTIVEIS', '01595271000108', 'Combustível caravana interior', 8700, $accounts[3]['id']],
        ];

        $expenseIds = [];
        $nfeSeed = 1;
        foreach ($expenses as $e) {
            $id = cuid();
            $expenseIds[] = $id;
            $nfe = generate_valid_nfe_key($nfeSeed++);
            $docDigits = only_digits($e[1]);
            $supplierId = $supplierMap[$docDigits] ?? null;
            $supplierName = $docDigits;
            if ($supplierId) {
                $sn = $pdo->prepare('SELECT name FROM `Supplier` WHERE id = ? LIMIT 1');
                $sn->execute([$supplierId]);
                $supplierName = (string) ($sn->fetch()['name'] ?? $docDigits);
            }
            $pdo->prepare(
                'INSERT INTO `Expense` (id, campaignId, category, supplierName, supplierDoc, supplierId, description, amount, date, status, nfeKey, nfeValid, nfeValidatedAt, bankAccountId, createdById, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                $id, $campaign['id'], $e[0], $supplierName, format_cpf_cnpj($docDigits), $supplierId, $e[2], $e[3],
                '2026-07-15 12:00:00', 'PAGA', $nfe, 1, $now, $e[4], $master['id'], $now, $now,
            ]);
        }

        // Chave real (GO) — Natural Criacoes / DANFE ConsultaDANFE (44 dígitos)
        $realKey = '52260554016069000132550010000000401100000567';
        $idReal = cuid();
        $expenseIds[] = $idReal;
        $natDoc = '54016069000132';
        // Garante emitente da nota real no cadastro de fornecedores
        if (empty($supplierMap[$natDoc])) {
            $natId = cuid();
            $pdo->prepare(
                'INSERT INTO `Supplier` (id, campaignId, name, tradeName, documentType, document, city, state, category, notes, active, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,1,?,?)'
            )->execute([
                $natId, $campaign['id'], 'Natural Criacoes', 'Natural Criacoes', 'CNPJ', format_cpf_cnpj($natDoc),
                'Goiânia', 'GO', 'Brindes / lembranças', 'Emitente da NF-e exemplo (ConsultaDANFE)', $now, $now,
            ]);
            $supplierMap[$natDoc] = $natId;
        }
        $pdo->prepare(
            'INSERT INTO `Expense` (id, campaignId, category, supplierName, supplierDoc, supplierId, description, amount, date, status, nfeKey, nfeValid, nfeValidatedAt, bankAccountId, createdById, createdAt, updatedAt)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        )->execute([
            $idReal, $campaign['id'], 'GRAFICA', 'Natural Criacoes', format_cpf_cnpj($natDoc), $supplierMap[$natDoc] ?? null,
            'CHAVEIRO LEMBRANCA PIRENOPOLIS — NF-e real (ConsultaDANFE)', 192, '2026-05-18 14:20:00', 'PAGA',
            $realKey, 1, $now, $accounts[0]['id'], $master['id'], $now, $now,
        ]);

        $badKey = '52260654016069000132550010000000421100000591'; // DV propositalmente errado
        $idBad = cuid();
        $expenseIds[] = $idBad;
        $fbDoc = '13347016000117';
        $pdo->prepare(
            'INSERT INTO `Expense` (id, campaignId, category, supplierName, supplierDoc, supplierId, description, amount, date, status, nfeKey, nfeValid, nfeValidatedAt, bankAccountId, createdById, createdAt, updatedAt)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        )->execute([
            $idBad, $campaign['id'], 'IMPULSIONAMENTO', 'FACEBOOK SERVICOS ONLINE DO BRASIL LTDA.', format_cpf_cnpj($fbDoc), $supplierMap[$fbDoc] ?? null,
            'Lançamento com chave inválida — análise do gestor', 990, '2026-06-22 12:00:00', 'PAGA',
            $badKey, 0, null, $accounts[0]['id'], $master['id'], $now, $now,
        ]);

        // Sem chave de acesso → não exibe “Visualizar nota”
        $idNoKey = cuid();
        $expenseIds[] = $idNoKey;
        $pdo->prepare(
            'INSERT INTO `Expense` (id, campaignId, category, supplierName, description, amount, date, status, nfeKey, nfeValid, bankAccountId, createdById, createdAt, updatedAt)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        )->execute([
            $idNoKey, $campaign['id'], 'COMITE', 'Prestador sem NF',
            'Despesa sem chave de acesso — sem opção de visualizar nota', 500,
            '2026-07-01 12:00:00', 'PAGA', null, 0, $accounts[0]['id'], $master['id'], $now, $now,
        ]);

        foreach ($cabos as $i => $caboId) {
            $id = cuid();
            $expenseIds[] = $id;
            $nfe = generate_valid_nfe_key(100 + $i);
            $amount = 2200 + $i * 100;
            $pdo->prepare(
                'INSERT INTO `Expense` (id, campaignId, category, supplierName, description, amount, date, status, nfeKey, nfeValid, nfeValidatedAt, bankAccountId, caboId, createdById, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                $id, $campaign['id'], 'CABOS_ELEITORAIS', 'Folha cabos', 'Pagamento cabo — parcela 1',
                $amount, '2026-08-01 12:00:00', 'PAGA', $nfe, 1, $now, $accounts[1]['id'], $caboId, $master['id'], $now, $now,
            ]);
        }

        // bank transactions (sample)
        for ($i = 0; $i < min(8, count($revenueIds)); $i++) {
            $r = $revenues[$i];
            $pdo->prepare(
                'INSERT INTO `BankTransaction` (id, bankAccountId, date, description, amount, type, status, matchedRevenueId, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                cuid(), $r[5], $r[3] . ' 12:00:00', 'Crédito — ' . $r[4], $r[2], 'CREDITO',
                'CONCILIADO', $revenueIds[$i], $now, $now,
            ]);
        }
        for ($i = 0; $i < min(10, count($expenseIds)); $i++) {
            $e = $expenses[$i] ?? null;
            if (!$e) {
                break;
            }
            $pdo->prepare(
                'INSERT INTO `BankTransaction` (id, bankAccountId, date, description, amount, type, status, matchedExpenseId, createdAt, updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                cuid(), $e[4], '2026-07-15 12:00:00', 'Débito — ' . $e[2], -$e[3], 'DEBITO',
                'CONCILIADO', $expenseIds[$i], $now, $now,
            ]);
        }
        $pdo->prepare(
            'INSERT INTO `BankTransaction` (id, bankAccountId, date, description, amount, type, status, createdAt, updatedAt)
             VALUES (?,?,?,?,?,?,?,?,?)'
        )->execute([cuid(), $accounts[0]['id'], $now, 'TED pendente — transferência interna', -1500, 'DEBITO', 'PENDENTE', $now, $now]);
        $pdo->prepare(
            'INSERT INTO `BankTransaction` (id, bankAccountId, date, description, amount, type, status, notes, createdAt, updatedAt)
             VALUES (?,?,?,?,?,?,?,?,?,?)'
        )->execute([cuid(), $accounts[3]['id'], $now, 'Tarifa bancária divergente', -45.9, 'DEBITO', 'DIVERGENTE', 'Conferir extrato', $now, $now]);

        $pdo->prepare(
            'INSERT INTO `BalanceAdjustment` (id, bankAccountId, previousBalance, newBalance, difference, date, reason, createdById, createdAt)
             VALUES (?,?,?,?,?,?,?,?,?)'
        )->execute([
            cuid(), $accounts[0]['id'], 280000, 285400, 5400, $now,
            'Ajuste de abertura conforme extrato BB', $master['id'], $now,
        ]);

        $pdo->prepare(
            'INSERT INTO `AuditLog` (id, userId, action, entity, details, createdAt) VALUES (?,?,?,?,?,?)'
        )->execute([cuid(), $master['id'], 'LOAD_DEMO', 'SYSTEM', 'Base demonstrativa carregada', $now]);

        return [
            'users' => 4,
            'accounts' => count($accounts),
            'revenues' => count($revenues),
            'expenses' => count($expenseIds),
            'cabos' => count($cabos),
            'suppliers' => (int) ($tseSync['count'] ?? 0),
            'suppliersSource' => (string) ($tseSync['source'] ?? 'none'),
        ];
    }

    public static function wizardStatus(): array
    {
        $campaign = Metrics::getCampaign();
        $pdo = Database::pdo();
        $cid = $campaign['id'] ?? null;
        $counts = [
            'campanha' => $campaign ? 1 : 0,
            'contas' => $cid ? (int) $pdo->query("SELECT COUNT(*) AS c FROM `BankAccount` WHERE campaignId = " . $pdo->quote($cid) . " AND active = 1")->fetch()['c'] : 0,
            'vinculos' => $cid ? (int) $pdo->query("SELECT COUNT(*) AS c FROM `AccountMapping` WHERE campaignId = " . $pdo->quote($cid))->fetch()['c'] : 0,
            'fornecedores' => $cid ? (int) $pdo->query("SELECT COUNT(*) AS c FROM `Supplier` WHERE campaignId = " . $pdo->quote($cid))->fetch()['c'] : 0,
            'veiculos' => $cid ? (int) $pdo->query("SELECT COUNT(*) AS c FROM `Vehicle` WHERE campaignId = " . $pdo->quote($cid))->fetch()['c'] : 0,
            'cabos' => $cid ? (int) $pdo->query("SELECT COUNT(*) AS c FROM `CaboEleitoral` WHERE campaignId = " . $pdo->quote($cid))->fetch()['c'] : 0,
            'receitas' => $cid ? (int) $pdo->query("SELECT COUNT(*) AS c FROM `Revenue` WHERE campaignId = " . $pdo->quote($cid))->fetch()['c'] : 0,
            'despesas' => $cid ? (int) $pdo->query("SELECT COUNT(*) AS c FROM `Expense` WHERE campaignId = " . $pdo->quote($cid))->fetch()['c'] : 0,
        ];
        return $counts;
    }
}
