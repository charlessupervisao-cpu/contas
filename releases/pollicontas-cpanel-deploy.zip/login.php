<?php
require_once __DIR__ . '/bootstrap.php';
if (Auth::user()) {
    redirect('/admin/index.php');
}

$error = null;
$dbOk = null;
try {
    $dbOk = Database::ping();
} catch (Throwable $e) {
    $dbOk = false;
}

if (request_method() === 'POST') {
    $email = strtolower(trim((string) post('email', '')));
    $password = (string) post('password', '');
    $user = Auth::login($email, $password);
    if ($user) {
        redirect('/admin/index.php');
    }
    $error = 'E-mail ou senha inválidos.';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Entrar · <?= e(APP_NAME) ?></title>
  <link rel="stylesheet" href="<?= e(asset('assets/css/app.css')) ?>">
</head>
<body class="login-shell">
  <div class="login-card animate-rise">
    <div style="display:flex;align-items:center;gap:.8rem;margin-bottom:1.25rem">
      <div class="logo-mark">PC</div>
      <div>
        <div class="display" style="font-size:1.6rem;font-weight:800"><?= e(APP_NAME) ?></div>
        <div class="muted" style="font-size:.85rem"><?= e(APP_DOMAIN) ?></div>
      </div>
    </div>
    <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
    <form method="post" class="stack">
      <div class="field">
        <label class="label" for="email">E-mail</label>
        <input class="input" type="email" id="email" name="email" required value="<?= e((string) post('email', 'master@pollicontas.synetiq.com.br')) ?>">
      </div>
      <div class="field">
        <label class="label" for="password">Senha</label>
        <input class="input" type="password" id="password" name="password" required value="admin123">
      </div>
      <button class="btn btn-primary" type="submit" style="width:100%">Entrar no dashboard</button>
    </form>
    <div style="margin-top:1.25rem;font-size:.85rem" class="muted">
      Sistema <strong>interno</strong>: após o login abre o dashboard. Só o perfil <strong>Master</strong> altera dados; Financeiro, RH e Consulta entram só para ler.
    </div>
    <div style="margin-top:.75rem;font-size:.85rem" class="muted">
      Demo: master / financeiro / rh / consulta @pollicontas.synetiq.com.br · senha <strong>admin123</strong>
    </div>
    <div style="margin-top:1rem;display:flex;justify-content:flex-end;gap:1rem;font-size:.85rem">
      <span class="badge <?= $dbOk ? 'badge-ok' : 'badge-danger' ?>"><?= $dbOk ? 'MySQL OK' : 'MySQL offline' ?></span>
    </div>
  </div>
</body>
</html>
