(function () {
  var base = (document.body && document.body.getAttribute("data-base")) || "";

  document.addEventListener("keydown", function (e) {
    if (!e.key) return;
    var tag = (e.target && e.target.tagName) || "";
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || e.target.isContentEditable) return;

    var fMap = {
      F2: "/admin/lancamento.php?tipo=RECEITA",
      F3: "/admin/lancamento.php",
      F4: "/admin/lancamento.php?tipo=DESPESA",
      F5: "/admin/movimentacoes.php",
      F6: "/admin/diario.php",
      F7: "/admin/vinculos.php",
      F8: "/admin/conciliacao.php",
      Home: "/admin/index.php",
    };
    if (fMap[e.key]) {
      e.preventDefault();
      window.location.href = base + fMap[e.key];
      return;
    }

    // Atalhos 1–9 (dashboard / admin) — cada situação de lançamento
    if (/^[1-9]$/.test(e.key) && !e.ctrlKey && !e.metaKey && !e.altKey) {
      var tile = document.querySelector('[data-quick-key="' + e.key + '"]');
      if (tile && tile.getAttribute("href")) {
        e.preventDefault();
        window.location.href = tile.getAttribute("href");
      }
    }
  });

  var nfeInput = document.querySelector("[data-nfe-input]");
  var nfeStatus = document.querySelector("[data-nfe-status]");
  if (nfeInput && nfeStatus) {
    var timer = null;
    nfeInput.addEventListener("input", function () {
      clearTimeout(timer);
      timer = setTimeout(function () {
        var key = (nfeInput.value || "").replace(/\D/g, "");
        if (key.length < 44) {
          nfeStatus.textContent = "Informe a chave com 44 dígitos.";
          nfeStatus.className = "muted";
          return;
        }
        fetch(base + "/api/nfe.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key: key }),
        })
          .then(function (r) {
            return r.json();
          })
          .then(function (data) {
            if (data.valid) {
              nfeStatus.textContent = "NF-e válida · modelo " + (data.parsed && data.parsed.model);
              nfeStatus.className = "badge badge-ok";
            } else {
              nfeStatus.textContent = data.reason || "NF-e inválida";
              nfeStatus.className = "badge badge-danger";
            }
          })
          .catch(function () {
            nfeStatus.textContent = "Falha ao validar";
            nfeStatus.className = "badge badge-warn";
          });
      }, 350);
    });
  }

  var kindRadios = document.querySelectorAll("[data-kind-toggle]");
  if (kindRadios.length) {
    function syncKind() {
      var checked = document.querySelector("[data-kind-toggle]:checked");
      var kind = checked ? checked.value : "DESPESA";
      document.querySelectorAll("[data-kind-block]").forEach(function (el) {
        el.hidden = el.getAttribute("data-kind-block") !== kind;
      });
    }
    kindRadios.forEach(function (r) {
      r.addEventListener("change", syncKind);
    });
    syncKind();
  }
})();
