<?php
/** @var array $user */
/** @var string $activeModule */
$tabs = [
    ['id' => 'dashboard', 'label' => 'Início', 'href' => 'admin/index.php'],
    ['id' => 'movimentacoes', 'label' => 'Movim.', 'href' => 'admin/movimentacoes.php'],
    ['id' => 'despesas', 'label' => 'Despesas', 'href' => 'admin/despesas.php'],
    ['id' => 'receitas', 'label' => 'Receitas', 'href' => 'admin/receitas.php'],
    ['id' => 'contas', 'label' => 'Contas', 'href' => 'admin/contas.php'],
];
?>
    </main>
    <nav class="mobile-tabbar" aria-label="Navegação rápida">
      <?php foreach ($tabs as $tab): ?>
        <?php
          $allowed = VIEW_ROLES[$tab['id']] ?? ['MASTER'];
          if (!in_array($user['role'], $allowed, true) && $tab['id'] !== 'dashboard') continue;
        ?>
        <a class="mobile-tab <?= ($activeModule ?? '') === $tab['id'] ? 'mobile-tab-active' : '' ?>" href="<?= e(url_path($tab['href'])) ?>">
          <span><?= e($tab['label']) ?></span>
        </a>
      <?php endforeach; ?>
    </nav>
  </div>
</div>
<script src="<?= e(asset('assets/js/app.js')) ?>"></script>
</body>
</html>
