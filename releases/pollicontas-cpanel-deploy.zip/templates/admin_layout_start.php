<?php
/** @var array $user */
/** @var string $activeModule */
/** @var string $pageTitle */
$activeModule = $activeModule ?? 'dashboard';
$pageTitle = $pageTitle ?? APP_NAME;
$flash = flash_get();
$dadosMods = array_values(array_filter(MODULES, static fn ($m) => ($m['group'] ?? 'dados') === 'dados'));
$configMods = array_values(array_filter(MODULES, static fn ($m) => ($m['group'] ?? '') === 'config'));
$showConfig = false;
foreach ($configMods as $cm) {
    if (in_array($user['role'], $cm['roles'], true)) {
        $showConfig = true;
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#0f766e">
  <title><?= e($pageTitle) ?> · <?= e(APP_NAME) ?></title>
  <link rel="stylesheet" href="<?= e(asset('assets/css/app.css')) ?>">
</head>
<body data-base="<?= e(rtrim(env('APP_BASE', '') ?: '', '/')) ?>" class="<?= ($activeModule ?? '') === 'dashboard' ? 'dash-home' : '' ?>">
<div class="admin-shell">
  <aside class="sidebar">
    <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:1rem;padding:.25rem .4rem">
      <div class="logo-mark">PC</div>
      <div>
        <div class="display" style="font-weight:800;font-size:1.1rem"><?= e(APP_NAME) ?></div>
        <div class="muted" style="font-size:.75rem">Prestação de contas · <?= e((string) ELECTION_YEAR) ?></div>
      </div>
    </div>
    <nav>
      <div class="nav-group-label">Dados lançados</div>
      <?php foreach ($dadosMods as $mod): ?>
        <?php if (!in_array($user['role'], $mod['roles'], true)) continue; ?>
        <a class="<?= $activeModule === $mod['id'] ? 'active' : '' ?>" href="<?= e(url_path(ltrim($mod['href'], '/'))) ?>">
          <?= e($mod['label']) ?>
        </a>
      <?php endforeach; ?>

      <?php if ($showConfig): ?>
        <div class="nav-group-label" style="margin-top:1.1rem">Configuração</div>
        <?php foreach ($configMods as $mod): ?>
          <?php if (!in_array($user['role'], $mod['roles'], true)) continue; ?>
          <a class="nav-config <?= $activeModule === $mod['id'] ? 'active' : '' ?>" href="<?= e(url_path(ltrim($mod['href'], '/'))) ?>">
            <?= e($mod['label']) ?>
          </a>
        <?php endforeach; ?>
      <?php endif; ?>

      <a href="<?= e(url_path('logout.php')) ?>" style="margin-top:.75rem">Sair</a>
    </nav>
  </aside>
  <div>
    <main class="admin-main<?= ($activeModule ?? '') === 'dashboard' ? ' dash-main-inline' : '' ?>">
      <?php if (($activeModule ?? '') !== 'dashboard'): ?>
      <div class="topbar">
        <div>
          <div class="page-title"><?= e($pageTitle) ?></div>
          <div class="muted" style="font-size:.9rem"><?= e($user['name']) ?> · <?= e(ROLE_LABELS[$user['role']] ?? $user['role']) ?></div>
        </div>
        <div class="row-actions hide-mobile">
          <?php if (can_launch($user['role'])): ?>
            <a class="btn btn-primary" href="<?= e(url_path('admin/lancamento.php')) ?>">Novo lançamento (F3)</a>
          <?php else: ?>
            <span class="badge badge-warn">Somente leitura</span>
          <?php endif; ?>
          <a class="btn btn-secondary" href="<?= e(url_path('admin/index.php')) ?>">Dashboard</a>
        </div>
      </div>
      <?php endif; ?>
      <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type'] === 'danger' ? 'danger' : ($flash['type'] === 'ok' ? 'ok' : 'info')) ?> animate-fade">
          <?= e($flash['message']) ?>
        </div>
      <?php endif; ?>
