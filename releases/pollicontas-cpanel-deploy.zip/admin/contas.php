<?php
require_once dirname(__DIR__) . '/bootstrap.php';
$user = Auth::requireLogin('contas');
$activeModule = 'contas';
$pageTitle = 'Contas Bancárias';
$campaign = Metrics::getCampaign();
$pdo = Database::pdo();

if (request_method() === 'POST' && can_launch($user['role'])) {
    Auth::requireMaster();
    $st = $pdo->prepare('SELECT COUNT(*) AS c FROM `BankAccount` WHERE campaignId=? AND active=1');
    $st->execute([$campaign['id']]);
    $activeCount = (int) $st->fetch()['c'];
    if ($activeCount >= MAX_BANK_ACCOUNTS) {
        flash_set('danger', 'Máximo de 4 contas ativas.');
        redirect('/admin/contas.php');
    }
    $now = now_sql();
    $pdo->prepare(
        'INSERT INTO `BankAccount` (id, campaignId, label, bankName, bankCode, agency, accountNumber, accountType, balance, active, sortOrder, createdAt, updatedAt)
         VALUES (?,?,?,?,?,?,?,?,?,1,?,?,?)'
    )->execute([
        cuid(), $campaign['id'], trim((string)post('label')), trim((string)post('bankName')),
        trim((string)post('bankCode')), trim((string)post('agency')), trim((string)post('accountNumber')),
        trim((string)post('accountType','Corrente')), (float)post('balance',0), $activeCount, $now, $now,
    ]);
    flash_set('ok', 'Conta criada.');
    redirect('/admin/contas.php');
}

$accounts = $campaign ? Lancamento::listAccountsOrdered($campaign['id']) : [];
require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<div class="grid grid-2">
  <div class="stack">
    <?php foreach ($accounts as $i => $a): ?>
      <div class="panel">
        <div class="muted">Conta <?= $i+1 ?></div>
        <div class="display" style="font-size:1.3rem"><?= e($a['label']) ?></div>
        <div class="muted"><?= e($a['bankName']) ?> (<?= e($a['bankCode']) ?>)</div>
        <div>Ag <?= e($a['agency']) ?> · Cc <?= e($a['accountNumber']) ?></div>
        <div class="display" style="margin-top:.5rem"><?= e(money_br($a['balance'])) ?></div>
      </div>
    <?php endforeach; ?>
    <?php if (!$accounts): ?><div class="panel empty">Nenhuma conta cadastrada.</div><?php endif; ?>
  </div>
  <?php if (can_launch($user['role']) && count($accounts) < MAX_BANK_ACCOUNTS): ?>
  <div class="panel form-card">
    <h3 class="display" style="margin-top:0">Nova conta</h3>
    <form method="post">
      <div class="field"><label class="label">Rótulo</label><input class="input" name="label" required></div>
      <div class="grid grid-2">
        <div class="field"><label class="label">Banco</label><input class="input" name="bankName" required></div>
        <div class="field"><label class="label">Código</label><input class="input" name="bankCode" required></div>
      </div>
      <div class="grid grid-2">
        <div class="field"><label class="label">Agência</label><input class="input" name="agency" required></div>
        <div class="field"><label class="label">Conta</label><input class="input" name="accountNumber" required></div>
      </div>
      <div class="grid grid-2">
        <div class="field"><label class="label">Tipo</label><input class="input" name="accountType" value="Corrente"></div>
        <div class="field"><label class="label">Saldo inicial</label><input class="input" type="number" step="0.01" name="balance" value="0"></div>
      </div>
      <button class="btn btn-primary" type="submit">Salvar conta</button>
    </form>
  </div>
  <?php endif; ?>
</div>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
