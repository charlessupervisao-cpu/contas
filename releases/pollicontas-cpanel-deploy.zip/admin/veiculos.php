<?php
require_once dirname(__DIR__) . '/bootstrap.php';
$user = Auth::requireLogin('veiculos');
$activeModule = 'veiculos';
$pageTitle = 'Veículos';
$campaign = Metrics::getCampaign();
$pdo = Database::pdo();

if (request_method() === 'POST') {
    Auth::requireMaster();
    $action = (string) post('action', 'create');
    $now = now_sql();
    if ($action === 'toggle') {
        $pdo->prepare('UPDATE `Vehicle` SET active=?, updatedAt=? WHERE id=?')->execute([(int)post('active'), $now, post('id')]);
        flash_set('ok', 'Veículo atualizado.');
    } else {
        $plate = strtoupper(preg_replace('/[^A-Z0-9]/i', '', (string) post('plate')) ?? '');
        $label = trim((string) post('label'));
        if ($label === '' || $plate === '') {
            flash_set('danger', 'Rótulo e placa são obrigatórios.');
            redirect('/admin/veiculos.php');
        }
        $pdo->prepare(
            'INSERT INTO `Vehicle` (id,campaignId,label,plate,brand,model,year,type,color,ownerName,active,createdAt,updatedAt)
             VALUES (?,?,?,?,?,?,?,?,?,?,1,?,?)'
        )->execute([
            cuid(), $campaign['id'], $label, $plate, post('brand')?:null, post('model')?:null,
            post('year')?:null, post('type','Automóvel'), post('color')?:null, post('ownerName')?:null, $now, $now,
        ]);
        flash_set('ok', 'Veículo cadastrado.');
    }
    redirect('/admin/veiculos.php');
}
$rows = $pdo->prepare('SELECT * FROM `Vehicle` WHERE campaignId=? ORDER BY active DESC, label');
$rows->execute([$campaign['id'] ?? '']);
$rows = $rows->fetchAll();
require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<div class="grid grid-2">
  <div class="stack">
    <?php foreach ($rows as $v): ?>
      <div class="panel row-actions" style="justify-content:space-between">
        <div>
          <strong><?= e($v['label']) ?></strong>
          <div class="muted"><?= e($v['plate']) ?> · <?= e($v['brand']) ?> <?= e($v['model']) ?> · <?= e($v['type']) ?></div>
        </div>
        <div class="row-actions">
          <span class="badge <?= $v['active']?'badge-ok':'badge-warn' ?>"><?= $v['active']?'Ativo':'Inativo' ?></span>
          <?php if (can_launch($user['role'])): ?>
          <form method="post">
            <input type="hidden" name="action" value="toggle">
            <input type="hidden" name="id" value="<?= e($v['id']) ?>">
            <input type="hidden" name="active" value="<?= $v['active']?0:1 ?>">
            <button class="btn btn-secondary" type="submit"><?= $v['active']?'Desativar':'Ativar' ?></button>
          </form>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php if (can_launch($user['role'])): ?>
  <div class="panel form-card">
    <h3 class="display" style="margin-top:0">Novo veículo</h3>
    <form method="post">
      <div class="field"><label class="label">Rótulo</label><input class="input" name="label" required></div>
      <div class="field"><label class="label">Placa</label><input class="input" name="plate" required></div>
      <div class="grid grid-2">
        <div class="field"><label class="label">Marca</label><input class="input" name="brand"></div>
        <div class="field"><label class="label">Modelo</label><input class="input" name="model"></div>
      </div>
      <div class="grid grid-2">
        <div class="field"><label class="label">Ano</label><input class="input" name="year"></div>
        <div class="field"><label class="label">Tipo</label><input class="input" name="type" value="Automóvel"></div>
      </div>
      <button class="btn btn-primary" type="submit">Salvar</button>
    </form>
  </div>
  <?php endif; ?>
</div>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
