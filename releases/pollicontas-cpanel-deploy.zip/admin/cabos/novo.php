<?php
require_once dirname(dirname(__DIR__)) . '/bootstrap.php';
$user = Auth::requireMaster();
$activeModule = 'cabos';
$pageTitle = 'Novo cabo + contrato';
$campaign = Metrics::getCampaign();
$pdo = Database::pdo();

if (request_method() === 'POST') {
    $fullName = trim((string) post('fullName'));
    $cpf = only_digits((string) post('cpf'));
    if ($fullName === '' || !is_valid_cpf($cpf)) {
        flash_set('danger', 'Nome e CPF válidos são obrigatórios.');
        redirect('/admin/cabos/novo.php');
    }
    $now = now_sql();
    $caboId = cuid();
    try {
        $pdo->beginTransaction();
        $pdo->prepare(
            'INSERT INTO `CaboEleitoral` (id,campaignId,fullName,cpf,rg,birthDate,phone,email,address,city,state,zone,roleTitle,active,createdAt,updatedAt)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)'
        )->execute([
            $caboId, $campaign['id'], $fullName, $cpf, post('rg')?:null, post('birthDate')?:null,
            post('phone')?:null, post('email')?:null, post('address')?:null, post('city')?:null,
            post('state','GO'), post('zone')?:null, post('roleTitle','Cabo Eleitoral'), $now, $now,
        ]);
        if (post('startDate') && post('endDate') && post('monthlyValue')) {
            $monthly = (float) post('monthlyValue');
            $pdo->prepare(
                'INSERT INTO `Contract` (id,caboId,contractNumber,startDate,endDate,monthlyValue,totalValue,functionDesc,status,createdAt,updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                cuid(), $caboId,
                post('contractNumber') ?: ('CT-'.date('Ymd').'-'.substr($caboId,-4)),
                parse_date_input((string)post('startDate')), parse_date_input((string)post('endDate')),
                $monthly, $monthly * 3, post('functionDesc') ?: 'Contrato por prazo determinado',
                'ATIVO', $now, $now,
            ]);
        }
        $pdo->commit();
        flash_set('ok', 'Cabo cadastrado.');
        redirect('/admin/cabos.php');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash_set('danger', $e->getMessage());
        redirect('/admin/cabos/novo.php');
    }
}
require dirname(dirname(__DIR__)) . '/templates/admin_layout_start.php';
?>
<div class="panel form-card">
<form method="post" class="stack">
  <h3 class="display" style="margin:0">Dados pessoais</h3>
  <div class="field"><label class="label">Nome completo</label><input class="input" name="fullName" required></div>
  <div class="grid grid-2">
    <div class="field"><label class="label">CPF</label><input class="input" name="cpf" required></div>
    <div class="field"><label class="label">Telefone</label><input class="input" name="phone"></div>
  </div>
  <div class="grid grid-2">
    <div class="field"><label class="label">Cidade</label><input class="input" name="city" value="Goiânia"></div>
    <div class="field"><label class="label">Zona</label><input class="input" name="zone"></div>
  </div>
  <div class="field"><label class="label">Endereço</label><input class="input" name="address"></div>
  <h3 class="display" style="margin:0">Contrato (opcional)</h3>
  <div class="grid grid-2">
    <div class="field"><label class="label">Início</label><input class="input" type="date" name="startDate" value="2026-07-01"></div>
    <div class="field"><label class="label">Fim</label><input class="input" type="date" name="endDate" value="2026-10-05"></div>
  </div>
  <div class="grid grid-2">
    <div class="field"><label class="label">Valor mensal</label><input class="input" type="number" step="0.01" name="monthlyValue"></div>
    <div class="field"><label class="label">Nº contrato</label><input class="input" name="contractNumber"></div>
  </div>
  <div class="field"><label class="label">Função</label><textarea class="textarea" name="functionDesc">Articulação territorial e mobilização eleitoral por prazo determinado.</textarea></div>
  <button class="btn btn-primary" type="submit">Salvar</button>
</form>
</div>
<?php require dirname(dirname(__DIR__)) . '/templates/admin_layout_end.php'; ?>
