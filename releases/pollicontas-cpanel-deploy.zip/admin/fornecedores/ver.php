<?php

declare(strict_types=1);

require_once dirname(dirname(__DIR__)) . '/bootstrap.php';

$user = Auth::requireLogin('fornecedores');
$activeModule = 'fornecedores';
$pageTitle = 'Fornecedor';
$campaign = Metrics::getCampaign();
$pdo = Database::pdo();
$id = trim((string) get('id', ''));

$st = $pdo->prepare('SELECT * FROM `Supplier` WHERE id = ? AND campaignId = ? LIMIT 1');
$st->execute([$id, $campaign['id'] ?? '']);
$s = $st->fetch();
if (!$s) {
    flash_set('danger', 'Fornecedor não encontrado.');
    redirect('/admin/fornecedores.php');
}

$nf = $pdo->prepare(
    'SELECT * FROM `SupplierNfe` WHERE supplierId = ? ORDER BY dataEmissao DESC, numeroNf DESC'
);
$nf->execute([$id]);
$nfes = $nf->fetchAll();

$qtd = count($nfes);
$valor = array_sum(array_map(static fn ($n) => (float) $n['valor'], $nfes));

require dirname(dirname(__DIR__)) . '/templates/admin_layout_start.php';
?>
<div class="row-actions" style="margin-bottom:1rem">
  <a class="btn btn-ghost" href="<?= e(url_path('admin/fornecedores.php')) ?>">← Fornecedores</a>
  <?php if (can_launch($user['role'])): ?>
    <a class="btn btn-secondary" href="<?= e(url_path('admin/fornecedores.php?id=' . rawurlencode((string) $s['id']))) ?>#form-fornecedor">Editar</a>
  <?php endif; ?>
</div>

<div class="panel" style="margin-bottom:1rem">
  <h2 class="display" style="margin-top:0"><?= e((string) $s['name']) ?></h2>
  <div class="grid grid-4" style="margin-top:1rem">
    <div class="stat-chip"><div class="l">CNPJ / CPF</div><div class="n" style="font-size:1rem"><?= e((string) ($s['document'] ?: '—')) ?></div></div>
    <div class="stat-chip"><div class="l">Qtd NF-es</div><div class="n"><?= $qtd ?></div></div>
    <div class="stat-chip"><div class="l">Valor</div><div class="n" style="font-size:1.1rem"><?= e(money_br($valor)) ?></div></div>
    <div class="stat-chip"><div class="l">Município / UF</div><div class="n" style="font-size:.95rem"><?= e(trim(($s['city'] ?: '—') . ' / ' . ($s['state'] ?: '—'))) ?></div></div>
  </div>
</div>

<div class="panel table-wrap">
  <h3 class="display" style="margin-top:0">Notas fiscais (CSV DivulgaCandContas)</h3>
  <p class="muted">Todos os campos da aba NF-es: CNPJ emitente, natureza, modelo, data, nº NF/série, valor, UE, unidade arrecadadora, chave e link.</p>
  <table class="data">
    <thead>
      <tr>
        <th>CNPJ Emitente</th>
        <th>Nome do Emitente</th>
        <th>Natureza Op.</th>
        <th>Modelo</th>
        <th>Data Emissão</th>
        <th>Nº NF</th>
        <th>Nº Série</th>
        <th>Valor</th>
        <th>UE</th>
        <th>Unidade Arrecadadora</th>
        <th>Ue</th>
        <th>Chave</th>
        <th>Link</th>
      </tr>
    </thead>
    <tbody>
    <?php if (!$nfes): ?>
      <tr><td colspan="13" class="empty">Nenhuma NF-e importada para este emitente.</td></tr>
    <?php endif; ?>
    <?php foreach ($nfes as $n): ?>
      <tr>
        <td><?= e((string) $n['cnpjEmitente']) ?></td>
        <td><?= e((string) $n['nmEmitente']) ?></td>
        <td><?= e((string) ($n['naturezaOp'] ?: '—')) ?></td>
        <td><?= e((string) ($n['modelo'] ?: '—')) ?></td>
        <td><?= e($n['dataEmissao'] ? date_br($n['dataEmissao']) : '—') ?></td>
        <td><?= e((string) ($n['numeroNf'] ?: '—')) ?></td>
        <td><?= e((string) ($n['numeroSerie'] ?: '—')) ?></td>
        <td><?= e(money_br((float) $n['valor'])) ?></td>
        <td><?= e((string) ($n['ue'] ?: '—')) ?></td>
        <td><?= e((string) ($n['unidadeArrecadadora'] ?: '—')) ?></td>
        <td><?= e((string) ($n['dsUe'] ?: '—')) ?></td>
        <td>
          <?php
            $chave = trim((string) ($n['chaveAcesso'] ?? ''));
            $chaveDigits = only_digits($chave);
          ?>
          <?php if ($chave !== '' && strlen($chaveDigits) === 44): ?>
            <a href="<?= e(nfe_consultadanfe_url($chaveDigits)) ?>" target="_blank" rel="noopener"><?= e(format_nfe_key($chaveDigits)) ?></a>
          <?php elseif ($chave !== ''): ?>
            <code><?= e($chave) ?></code>
          <?php else: ?>
            —
          <?php endif; ?>
        </td>
        <td>
          <?php if (!empty($n['link']) && preg_match('#^https?://#i', (string) $n['link'])): ?>
            <a href="<?= e((string) $n['link']) ?>" target="_blank" rel="noopener">Abrir</a>
          <?php elseif (!empty($n['link'])): ?>
            <?= e((string) $n['link']) ?>
          <?php else: ?>
            —
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require dirname(dirname(__DIR__)) . '/templates/admin_layout_end.php'; ?>
