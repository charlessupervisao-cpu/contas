<?php
require_once dirname(__DIR__) . '/bootstrap.php';
$user = Auth::requireLogin('usuarios');
$activeModule = 'usuarios';
$pageTitle = 'Usuários / Perfis';
$pdo = Database::pdo();
$rows = $pdo->query('SELECT id,name,email,role,active,createdAt FROM `User` ORDER BY role, name')->fetchAll();
require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<div class="panel" style="margin-bottom:1rem">
  <p class="muted" style="margin-top:0">Acesso por perfil. Somente <strong>Master</strong> pode lançar receitas, despesas, cabos, contas e conciliação.</p>
  <div class="grid grid-2">
    <?php foreach (PROFILE_MATRIX as $code => $p): ?>
      <div class="glass" style="padding:1rem;border-radius:1rem">
        <div class="row-actions" style="justify-content:space-between">
          <strong><?= e($p['label']) ?></strong>
          <span class="badge <?= $p['canLaunch'] ? 'badge-ok' : 'badge-info' ?>"><?= $p['canLaunch'] ? 'Pode lançar' : 'Somente leitura' ?></span>
        </div>
        <div class="muted" style="margin-top:.35rem;font-size:.9rem"><?= e($p['description']) ?></div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<div class="panel table-wrap">
<table class="data">
  <thead><tr><th>Nome</th><th>E-mail</th><th>Perfil</th><th>Lançamentos</th><th>Status</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): $role = normalize_role($r['role']); ?>
    <tr>
      <td><?= e($r['name']) ?></td>
      <td><?= e($r['email']) ?></td>
      <td><?= e(ROLE_LABELS[$role] ?? $role) ?></td>
      <td><?= can_launch($role) ? '<span class="badge badge-ok">Sim</span>' : '<span class="badge badge-info">Não</span>' ?></td>
      <td><span class="badge <?= $r['active'] ? 'badge-ok' : 'badge-warn' ?>"><?= $r['active'] ? 'Ativo' : 'Inativo' ?></span></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
