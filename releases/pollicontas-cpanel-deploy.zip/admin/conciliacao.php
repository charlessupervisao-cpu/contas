<?php
require_once dirname(__DIR__) . '/bootstrap.php';
$user = Auth::requireLogin('conciliacao');
$activeModule = 'conciliacao';
$pageTitle = 'Conciliação';
$campaign = Metrics::getCampaign();
$pdo = Database::pdo();
$accounts = $campaign ? Lancamento::listAccountsOrdered($campaign['id']) : [];
$accountId = (string) get('accountId', $accounts[0]['id'] ?? '');

if (request_method() === 'POST') {
    Auth::requireMaster();
    $id = (string) post('id');
    $status = (string) post('status');
    if (!in_array($status, ['PENDENTE','CONCILIADO','DIVERGENTE'], true)) {
        flash_set('danger', 'Status inválido.');
        redirect('/admin/conciliacao.php?accountId=' . urlencode($accountId));
    }
    $now = now_sql();
    $pdo->prepare('UPDATE `BankTransaction` SET status=?, notes=COALESCE(?, notes), updatedAt=? WHERE id=?')
        ->execute([$status, post('notes') ?: null, $now, $id]);
    $pdo->prepare('INSERT INTO `AuditLog` (id,userId,action,entity,entityId,details,createdAt) VALUES (?,?,?,?,?,?,?)')
        ->execute([cuid(), $user['id'], 'RECONCILE', 'BankTransaction', $id, 'Status → '.$status, $now]);
    flash_set('ok', 'Transação atualizada.');
    redirect('/admin/conciliacao.php?accountId=' . urlencode($accountId));
}

$params = [];
$sql = 'SELECT t.*, a.label AS accountLabel FROM `BankTransaction` t INNER JOIN `BankAccount` a ON a.id=t.bankAccountId WHERE a.campaignId=?';
$params[] = $campaign['id'] ?? '';
if ($accountId) { $sql .= ' AND t.bankAccountId=?'; $params[] = $accountId; }
$sql .= ' ORDER BY t.date DESC LIMIT 200';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();
$summary = ['PENDENTE'=>0,'CONCILIADO'=>0,'DIVERGENTE'=>0];
foreach ($rows as $r) $summary[$r['status']] = ($summary[$r['status']] ?? 0) + 1;
require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<form method="get" class="row-actions" style="margin-bottom:1rem">
  <select class="select" name="accountId" onchange="this.form.submit()" style="max-width:320px">
    <?php foreach ($accounts as $i=>$a): ?>
      <option value="<?= e($a['id']) ?>" <?= $accountId===$a['id']?'selected':'' ?>>Conta <?= $i+1 ?> — <?= e($a['label']) ?></option>
    <?php endforeach; ?>
  </select>
  <span class="badge badge-warn">Pendentes <?= (int)$summary['PENDENTE'] ?></span>
  <span class="badge badge-ok">Conciliados <?= (int)$summary['CONCILIADO'] ?></span>
  <span class="badge badge-danger">Divergentes <?= (int)$summary['DIVERGENTE'] ?></span>
</form>
<div class="panel table-wrap">
<table class="data">
  <thead><tr><th>Data</th><th>Descrição</th><th>Valor</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e(date_br($r['date'])) ?></td>
      <td><?= e($r['description']) ?></td>
      <td><strong><?= e(money_br($r['amount'])) ?></strong></td>
      <td><span class="badge <?= $r['status']==='CONCILIADO'?'badge-ok':($r['status']==='DIVERGENTE'?'badge-danger':'badge-warn') ?>"><?= e($r['status']) ?></span></td>
      <td>
        <?php if (can_launch($user['role'])): ?>
        <form method="post" class="row-actions">
          <input type="hidden" name="id" value="<?= e($r['id']) ?>">
          <button class="btn btn-secondary" name="status" value="CONCILIADO" type="submit">OK</button>
          <button class="btn btn-secondary" name="status" value="DIVERGENTE" type="submit">Div.</button>
          <button class="btn btn-ghost" name="status" value="PENDENTE" type="submit">Pend.</button>
        </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
