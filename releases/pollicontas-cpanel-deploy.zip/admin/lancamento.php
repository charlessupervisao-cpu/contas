<?php
require_once dirname(__DIR__) . '/bootstrap.php';
$user = Auth::requireLogin('lancamento');
$activeModule = 'lancamento';
$pageTitle = 'Lançamento';
$pdo = Database::pdo();
$campaign = Metrics::getCampaign();
$accounts = $campaign ? Lancamento::listAccountsOrdered($campaign['id']) : [];
$cid = $campaign['id'] ?? '';
$supStmt = $pdo->prepare('SELECT id,name FROM `Supplier` WHERE campaignId=? AND active=1 ORDER BY name');
$supStmt->execute([$cid]);
$suppliers = $supStmt->fetchAll();
$cabosStmt = $pdo->prepare('SELECT id,fullName FROM `CaboEleitoral` WHERE campaignId=? AND active=1 ORDER BY fullName');
$cabosStmt->execute([$cid]);
$cabos = $cabosStmt->fetchAll();
$vehStmt = $pdo->prepare('SELECT id,label,plate FROM `Vehicle` WHERE campaignId=? AND active=1 ORDER BY label');
$vehStmt->execute([$cid]);
$vehicles = $vehStmt->fetchAll();

$tipo = strtoupper((string) get('tipo', 'DESPESA'));
if (!in_array($tipo, ['RECEITA', 'DESPESA'], true)) $tipo = 'DESPESA';

if (request_method() === 'POST') {
    Auth::requireMaster();
    $kind = (string) post('kind', $tipo);
    $category = (string) post('category', '');
    $source = (string) post('source', '');
    $bankAccountId = (string) post('bankAccountId', '');
    if ($bankAccountId === '' && $campaign) {
        if ($kind === 'RECEITA' && $source) {
            $bankAccountId = Lancamento::getDefaultAccountId($campaign['id'], 'REVENUE_SOURCE', $source) ?? '';
        }
        if ($kind === 'DESPESA' && $category) {
            $bankAccountId = Lancamento::getDefaultAccountId($campaign['id'], 'EXPENSE_CATEGORY', $category) ?? '';
        }
    }
    $result = Lancamento::create([
        'kind' => $kind,
        'amount' => post('amount'),
        'date' => post('date'),
        'description' => post('description'),
        'bankAccountId' => $bankAccountId,
        'source' => $source,
        'donorName' => post('donorName'),
        'donorCpf' => post('donorCpf'),
        'receiptNumber' => post('receiptNumber'),
        'category' => $category,
        'supplierId' => post('supplierId') ?: null,
        'supplierName' => post('supplierName'),
        'nfeKey' => post('nfeKey'),
        'allowInvalidNfe' => (bool) post('allowInvalidNfe'),
        'caboId' => post('caboId') ?: null,
        'vehicleId' => post('vehicleId') ?: null,
    ], $user['id']);
    if ($result['ok']) {
        $msg = 'Lançamento registrado com sucesso.';
        if ($kind === 'DESPESA' && post('allowInvalidNfe') && !validate_nfe_key(only_digits((string) post('nfeKey')))['valid']) {
            $msg = 'Despesa registrada com NF-e INVÁLIDA — aparece em vermelho na lista para análise do gestor.';
        }
        flash_set('ok', $msg);
        redirect('/admin/lancamento.php?tipo=' . urlencode($kind));
    }
    flash_set('danger', $result['error'] ?? 'Erro ao lançar.');
    redirect('/admin/lancamento.php?tipo=' . urlencode($kind));
}

require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<div class="panel form-card animate-rise">
  <?php if (!can_launch($user['role'])): ?>
    <div class="alert alert-warn">Somente o perfil Master pode lançar. Você está em modo consulta.</div>
  <?php endif; ?>
  <form method="post">
    <div class="field row-actions">
      <label><input type="radio" name="kind" value="RECEITA" data-kind-toggle <?= $tipo==='RECEITA'?'checked':'' ?>> Receita</label>
      <label><input type="radio" name="kind" value="DESPESA" data-kind-toggle <?= $tipo==='DESPESA'?'checked':'' ?>> Despesa</label>
    </div>
    <div class="grid grid-2">
      <div class="field">
        <label class="label">Valor</label>
        <input class="input" type="number" step="0.01" min="0.01" name="amount" required <?= can_launch($user['role'])?'':'disabled' ?>>
      </div>
      <div class="field">
        <label class="label">Data</label>
        <input class="input" type="date" name="date" value="<?= e(date('Y-m-d')) ?>" <?= can_launch($user['role'])?'':'disabled' ?>>
      </div>
    </div>
    <div class="field">
      <label class="label">Conta bancária</label>
      <select class="select" name="bankAccountId" <?= can_launch($user['role'])?'':'disabled' ?>>
        <option value="">Usar vínculo padrão da categoria/fonte</option>
        <?php foreach ($accounts as $i => $a): ?>
          <option value="<?= e($a['id']) ?>">Conta <?= $i+1 ?> — <?= e($a['label']) ?> (<?= e(money_br($a['balance'])) ?>)</option>
        <?php endforeach; ?>
      </select>
    </div>

    <div data-kind-block="RECEITA">
      <div class="field">
        <label class="label">Fonte</label>
        <select class="select" name="source">
          <?php foreach (REVENUE_SOURCES as $code => $label): ?>
            <option value="<?= e($code) ?>"><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="grid grid-2">
        <div class="field"><label class="label">Nome do doador</label><input class="input" name="donorName"></div>
        <div class="field"><label class="label">CPF do doador</label><input class="input" name="donorCpf"></div>
      </div>
      <div class="field"><label class="label">Recibo</label><input class="input" name="receiptNumber"></div>
      <div class="field"><label class="label">Descrição</label><textarea class="textarea" name="description"></textarea></div>
    </div>

    <div data-kind-block="DESPESA">
      <div class="field">
        <label class="label">Categoria</label>
        <select class="select" name="category">
          <?php foreach (EXPENSE_CATEGORIES as $code => $label): ?>
            <option value="<?= e($code) ?>"><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label class="label">Fornecedor</label>
        <select class="select" name="supplierId">
          <option value="">— selecionar —</option>
          <?php foreach ($suppliers as $s): ?>
            <option value="<?= e($s['id']) ?>"><?= e($s['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field"><label class="label">Ou nome do fornecedor</label><input class="input" name="supplierName"></div>
      <div class="field">
        <label class="label">Chave de acesso NF-e (44 dígitos)</label>
        <input class="input" name="nfeKey" data-nfe-input maxlength="54" inputmode="numeric" autocomplete="off" placeholder="Ex.: 52260654016069000132550010000000421100000590" <?= can_launch($user['role'])?'':'disabled' ?>>
        <div data-nfe-status class="muted" style="margin-top:.35rem">Cole a chave completa da DANFE (44 números).</div>
        <label class="row-actions" style="margin-top:.55rem;font-size:.85rem">
          <input type="checkbox" name="allowInvalidNfe" value="1" <?= can_launch($user['role'])?'':'disabled' ?>>
          Registrar mesmo se a chave for inválida (linha em vermelho para análise do gestor)
        </label>
      </div>
      <div class="field"><label class="label">Descrição</label><textarea class="textarea" name="description"></textarea></div>
      <div class="grid grid-2">
        <div class="field">
          <label class="label">Cabo (se aplicável)</label>
          <select class="select" name="caboId"><option value="">—</option>
            <?php foreach ($cabos as $c): ?><option value="<?= e($c['id']) ?>"><?= e($c['fullName']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label class="label">Veículo</label>
          <select class="select" name="vehicleId"><option value="">—</option>
            <?php foreach ($vehicles as $v): ?><option value="<?= e($v['id']) ?>"><?= e($v['label']) ?> · <?= e($v['plate']) ?></option><?php endforeach; ?>
          </select>
        </div>
      </div>
    </div>

    <?php if (can_launch($user['role'])): ?>
      <button class="btn btn-primary" type="submit">Registrar lançamento</button>
    <?php endif; ?>
  </form>
</div>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
