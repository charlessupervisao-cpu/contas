<?php
require_once dirname(__DIR__) . '/bootstrap.php';
$user = Auth::requireLogin('cabos');
$activeModule = 'cabos';
$pageTitle = 'Cabos / Contratos';
$pdo = Database::pdo();
$rows = $pdo->query(
    'SELECT c.*,
      (SELECT COUNT(*) FROM `Contract` ct WHERE ct.caboId=c.id AND ct.status="ATIVO") AS contratosAtivos,
      (SELECT COALESCE(SUM(monthlyValue),0) FROM `Contract` ct WHERE ct.caboId=c.id AND ct.status="ATIVO") AS folha
     FROM `CaboEleitoral` c ORDER BY c.fullName'
)->fetchAll();
$ativos = count(array_filter($rows, fn ($r) => (int) $r['active'] === 1));
$folha = array_sum(array_map(fn ($r) => (float) $r['folha'], $rows));
$contratos = array_sum(array_map(fn ($r) => (int) $r['contratosAtivos'], $rows));
require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<div class="grid grid-4" style="margin-bottom:1rem">
  <div class="stat-chip"><div class="l">Cadastrados</div><div class="n"><?= count($rows) ?></div></div>
  <div class="stat-chip"><div class="l">Ativos</div><div class="n"><?= $ativos ?></div></div>
  <div class="stat-chip"><div class="l">Contratos ativos</div><div class="n"><?= $contratos ?></div></div>
  <div class="stat-chip"><div class="l">Folha mensal</div><div class="n" style="font-size:1.1rem"><?= e(money_br($folha)) ?></div></div>
</div>
<div class="row-actions" style="margin-bottom:1rem;justify-content:space-between">
  <div class="muted">Cadastro de cabos eleitorais — campanha <?= e((string) ELECTION_YEAR) ?> · reeleição <?= e(DEFAULT_OFFICE) ?>/<?= e(DEFAULT_STATE) ?></div>
  <?php if (can_launch($user['role'])): ?>
    <a class="btn btn-primary" href="<?= e(url_path('admin/cabos/novo.php')) ?>">Cadastrar + contrato <span class="kbd">9</span></a>
  <?php endif; ?>
</div>
<div class="grid grid-2">
<?php foreach ($rows as $c): ?>
  <div class="panel">
    <div class="row-actions" style="justify-content:space-between">
      <strong><?= e($c['fullName']) ?></strong>
      <span class="badge <?= $c['active']?'badge-ok':'badge-warn' ?>"><?= $c['active']?'Ativo':'Inativo' ?></span>
    </div>
    <div class="muted">CPF <?= e($c['cpf']) ?> · <?= e($c['city'] ?: '—') ?> · <?= e($c['zone'] ?: '') ?></div>
    <div style="margin-top:.5rem">Contratos ativos: <?= (int)$c['contratosAtivos'] ?> · Folha <?= e(money_br($c['folha'])) ?></div>
  </div>
<?php endforeach; ?>
</div>
<?php if (!$rows): ?><div class="panel empty">Nenhum cabo cadastrado.</div><?php endif; ?>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
