<?php
require_once dirname(__DIR__) . '/bootstrap.php';
$user = Auth::requireLogin('despesas');
$activeModule = 'despesas';
$pageTitle = 'Despesas';
$pdo = Database::pdo();
$rows = $pdo->query(
    "SELECT e.*, a.label AS accountLabel FROM `Expense` e
     LEFT JOIN `BankAccount` a ON a.id = e.bankAccountId
     WHERE e.status <> 'CANCELADA'
     ORDER BY e.date DESC"
)->fetchAll();

// Revalida a chave na exibição (fonte da verdade visual para o gestor)
foreach ($rows as &$r) {
    $check = $r['nfeKey'] ? validate_nfe_key((string) $r['nfeKey']) : ['valid' => false, 'reason' => 'Sem chave'];
    $r['_nfeCheck'] = $check;
    $r['_nfeOk'] = !empty($check['valid']);
}
unset($r);

$total = array_sum(array_map(fn ($r) => (float) $r['amount'], $rows));
$byCat = [];
foreach (EXPENSE_CATEGORIES as $code => $label) {
    $items = array_values(array_filter($rows, fn ($r) => $r['category'] === $code));
    $byCat[] = [
        'code' => $code,
        'label' => $label,
        'count' => count($items),
        'amount' => array_sum(array_map(fn ($r) => (float) $r['amount'], $items)),
        'color' => EXPENSE_CATEGORY_COLORS[$code],
    ];
}
$metrics = Metrics::getDashboardMetrics();
$vf = $metrics['vehicleFuel'] ?? null;
$nfeOk = count(array_filter($rows, fn ($r) => $r['_nfeOk']));
$nfeWithKey = count(array_filter($rows, fn ($r) => nfe_has_access_key($r['nfeKey'] ?? null)));
$nfeBad = count(array_filter($rows, fn ($r) => nfe_has_access_key($r['nfeKey'] ?? null) && !$r['_nfeOk']));
$nfeMissing = count($rows) - $nfeWithKey;
require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<?php if ($vf): ?>
<div class="panel" style="margin-bottom:1rem">
  <div class="row-actions" style="justify-content:space-between">
    <div>
      <strong>Limite Veículos + Combustíveis = 20% do orçamento</strong>
      <div class="muted"><?= e(money_br($vf['amount'])) ?> de <?= e(money_br($vf['limit'])) ?> · resta <?= e(money_br($vf['remaining'])) ?></div>
    </div>
    <span class="badge <?= $vf['withinLimit'] ? 'badge-ok' : 'badge-danger' ?>"><?= $vf['withinLimit'] ? 'Dentro do limite' : 'Excedido' ?></span>
  </div>
  <div class="progress-track" style="margin-top:.6rem"><div class="progress-fill" style="width:<?= min(100, $vf['limit'] > 0 ? ($vf['amount'] / $vf['limit']) * 100 : 0) ?>%;background:<?= $vf['withinLimit'] ? '' : 'var(--danger)' ?>"></div></div>
</div>
<?php endif; ?>

<div class="row-actions" style="margin-bottom:1rem;justify-content:space-between">
  <div class="muted">
    Total: <strong><?= e(money_br($total)) ?></strong> ·
    <?= count($rows) ?> registros ·
    <span class="badge badge-ok"><?= $nfeOk ?> com chave válida</span>
    <?php if ($nfeBad > 0): ?>
      <span class="badge badge-danger"><?= $nfeBad ?> chave inválida</span>
    <?php endif; ?>
    <?php if ($nfeMissing > 0): ?>
      <span class="badge badge-warn"><?= $nfeMissing ?> sem chave (sem visualizar)</span>
    <?php endif; ?>
  </div>
  <?php if (can_launch($user['role'])): ?>
    <a class="btn btn-primary" href="<?= e(url_path('admin/lancamento.php?tipo=DESPESA')) ?>">Nova despesa <span class="kbd">F4</span></a>
  <?php endif; ?>
</div>

<div class="grid grid-4" style="margin-bottom:1rem">
  <?php foreach ($byCat as $s): ?>
    <div class="stat-chip">
      <div class="l" style="color:<?= e($s['color']) ?>"><?= e($s['label']) ?></div>
      <div class="n" style="font-size:1.15rem"><?= e(money_br($s['amount'])) ?></div>
      <div class="muted" style="font-size:.75rem"><?= (int) $s['count'] ?> · <?= $total > 0 ? e(percent_br($s['amount'] / $total)) : '0%' ?></div>
    </div>
  <?php endforeach; ?>
</div>

<div class="panel" style="margin-bottom:1rem;font-size:.9rem">
  <strong>Legenda NF-e:</strong>
  <span class="nfe-status nfe-status-ok" title="Com chave">✓ Visualizar nota</span> abre o DANFE (ConsultaDANFE) pela chave de acesso ·
  Sem chave → sem opção de visualizar ·
  <span class="nfe-status nfe-status-bad" title="Inválida">✗</span> chave inválida (ainda pode tentar visualizar se tiver 44 dígitos)
</div>

<div class="panel table-wrap">
<table class="data">
  <thead>
    <tr>
      <th>Data</th>
      <th>Categoria</th>
      <th>Fornecedor</th>
      <th>Chave NF-e (44 dígitos)</th>
      <th>Status</th>
      <th>Conta</th>
      <th>Valor</th>
    </tr>
  </thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="7" class="empty">Nenhuma despesa.</td></tr><?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <?php
      $hasKey = nfe_has_access_key($r['nfeKey'] ?? null);
      $ok = $r['_nfeOk'];
    ?>
    <tr class="<?= ($hasKey && !$ok) ? 'row-nfe-invalid' : '' ?>">
      <td><?= e(date_br($r['date'])) ?></td>
      <td><?= e(EXPENSE_CATEGORIES[$r['category']] ?? $r['category']) ?></td>
      <td>
        <?= e($r['supplierName']) ?>
        <div class="muted" style="font-size:.75rem"><?= e(mb_strimwidth($r['description'], 0, 60, '…')) ?></div>
      </td>
      <td>
        <?php if (nfe_has_access_key($r['nfeKey'] ?? null)): ?>
          <a class="nfe-key-link" href="<?= e(nfe_nota_url($r['id'])) ?>" target="_blank" rel="noopener" title="Visualizar nota fiscal (DANFE)">
            <code class="nfe-key"><?= e(format_nfe_key((string) $r['nfeKey'])) ?></code>
          </a>
        <?php else: ?>
          <span class="muted">— sem chave —</span>
        <?php endif; ?>
      </td>
      <td>
        <?php if (nfe_has_access_key($r['nfeKey'] ?? null)): ?>
          <a class="nfe-status nfe-status-ok"
             href="<?= e(nfe_nota_url($r['id'])) ?>"
             target="_blank" rel="noopener"
             title="Visualizar nota fiscal (DANFE)">✓ Visualizar nota</a>
          <?php if (!$ok): ?>
            <div class="nfe-reason"><?= e($r['_nfeCheck']['reason'] ?? 'Chave com alerta') ?></div>
          <?php endif; ?>
        <?php else: ?>
          <span class="muted">—</span>
        <?php endif; ?>
      </td>
      <td><?= e($r['accountLabel'] ?: '—') ?></td>
      <td><strong><?= e(money_br($r['amount'])) ?></strong></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
