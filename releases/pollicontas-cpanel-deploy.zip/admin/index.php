<?php
/**
 * Dashboard financeiro — modelo Cobre Fácil:
 * 1) Visão geral (KPIs) → 2) Análises (gráficos) → 3) Detalhes.
 * Ref: https://www.cobrefacil.com.br/blog/dashboard-financeiro
 */
require_once dirname(__DIR__) . '/bootstrap.php';
$user = Auth::requireLogin('dashboard');
$activeModule = 'dashboard';
$pageTitle = 'Dashboard financeiro';
$metrics = null;
$error = null;
try {
    $metrics = Metrics::getDashboardMetrics();
} catch (Throwable $e) {
    $error = $e->getMessage();
}

$cashFlow = [];
$recent = [];
if ($metrics) {
    $cashFlow = Metrics::getMonthlyCashFlow(6);
    $recent = Metrics::getRecentMovements(12);
}
$maxFlow = 1.0;
foreach ($cashFlow as $cf) {
    $maxFlow = max($maxFlow, (float) $cf['entrada'], (float) $cf['saida']);
}

require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<?php if ($error): ?>
  <div class="alert alert-danger">Banco indisponível: <?= e($error) ?>.</div>
<?php elseif (!$metrics): ?>
  <div class="alert alert-warn">Nenhuma campanha encontrada. Cadastre em Configuração → Campanha / foto.</div>
<?php else: ?>
  <?php
    $t = $metrics['totals'];
    $c = $metrics['counts'];
    $vf = $metrics['vehicleFuel'];
    $camp = $metrics['campaign'];
    $saldoBancos = array_sum(array_column($metrics['bankBalances'], 'balance'));
    $ranking = $metrics['rankingDespesas'] ?? [];
    $maxRank = max(1, ...array_map(static fn ($r) => (float) $r['amount'], $ranking ?: [['amount' => 0]]));
    $chartH = 170;
    $chartPad = 30;
    $nBars = max(1, count($cashFlow));
    $slot = 100 / $nBars;

    // Comparativo mês atual × mês anterior (fluxo)
    $mesAtual = $cashFlow[count($cashFlow) - 1] ?? ['entrada' => 0, 'saida' => 0, 'saldo' => 0, 'label' => '—'];
    $mesAnt = $cashFlow[count($cashFlow) - 2] ?? ['entrada' => 0, 'saida' => 0, 'saldo' => 0, 'label' => '—'];
    $deltaReceita = (float) $mesAnt['entrada'] > 0
      ? (((float) $mesAtual['entrada'] - (float) $mesAnt['entrada']) / (float) $mesAnt['entrada'])
      : ((float) $mesAtual['entrada'] > 0 ? 1 : 0);
    $deltaDespesa = (float) $mesAnt['saida'] > 0
      ? (((float) $mesAtual['saida'] - (float) $mesAnt['saida']) / (float) $mesAnt['saida'])
      : ((float) $mesAtual['saida'] > 0 ? 1 : 0);
    $margem = (float) $t['totalReceitas'] > 0 ? ((float) $t['saldo'] / (float) $t['totalReceitas']) : 0;

    // Donut receitas
    $donut = [];
    $angle = -90.0;
    foreach ($metrics['receitasPorFonte'] as $row) {
        $share = (float) ($row['share'] ?? 0);
        $sweep = $share * 360;
        $donut[] = [
            'label' => $row['label'],
            'color' => REVENUE_SOURCE_COLORS[$row['source']] ?? '#0f766e',
            'amount' => (float) $row['amount'],
            'share' => $share,
            'start' => $angle,
            'sweep' => max(0.01, $sweep),
        ];
        $angle += $sweep;
    }
    $photoUrl = !empty($camp['photoUrl']) ? url_path(ltrim((string) $camp['photoUrl'], '/')) : '';
  ?>

  <?php if (!can_launch($user['role'])): ?>
    <div class="alert alert-info animate-fade">Modo <strong>somente leitura</strong> — consulta dos dados lançados.</div>
  <?php endif; ?>

  <!-- Identidade compacta -->
  <header class="fin-identity animate-rise">
    <div class="fin-identity-main">
      <div class="candidate-photo-frame compact">
        <?php if ($photoUrl): ?>
          <img src="<?= e($photoUrl) ?>" alt="Foto de <?= e($camp['candidateName']) ?>" width="72" height="96">
        <?php else: ?>
          <span class="photo-placeholder">Sem foto</span>
        <?php endif; ?>
      </div>
      <div>
        <div class="fin-kicker">Dashboard financeiro · saúde da campanha</div>
        <h1 class="fin-title"><?= e($camp['candidateName']) ?> <span><?= e($camp['candidateNumber']) ?></span></h1>
        <p class="fin-sub">
          <?= e($camp['office'] ?: DEFAULT_OFFICE) ?> · <?= e($camp['party']) ?>/<?= e($camp['partyNumber']) ?>
          · <?= e($camp['state'] ?: 'GO') ?> <?= e((string) ($camp['electionYear'] ?? ELECTION_YEAR)) ?>
          <?php if (!empty($camp['cnpjCampaign'])): ?>
            · CNPJ <?= e(preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', only_digits((string) $camp['cnpjCampaign']))) ?>
          <?php endif; ?>
        </p>
      </div>
    </div>
    <div class="fin-identity-side">
      <div class="fin-pill">Orçamento <strong><?= e(money_br($t['orcamento'])) ?></strong></div>
      <div class="fin-pill">Limite legal <strong><?= e(money_br($t['limiteLegal'])) ?></strong></div>
      <div class="fin-pill"><?= e($camp['situation'] ?: 'Em campanha') ?></div>
    </div>
  </header>

  <!-- 1. VISÃO GERAL — 5 a 8 indicadores -->
  <div class="fin-zone">
    <div class="fin-zone-label"><span>1</span> Visão geral</div>
    <section class="fin-kpi-grid animate-rise">
      <article class="fin-kpi in">
        <div class="fin-kpi-label">Faturamento / Receitas</div>
        <div class="fin-kpi-value"><?= e(money_br($t['totalReceitas'])) ?></div>
        <div class="fin-kpi-meta">
          <?= (int) $c['receitas'] ?> entradas
          <span class="delta <?= $deltaReceita >= 0 ? 'up' : 'down' ?>">
            <?= $deltaReceita >= 0 ? '▲' : '▼' ?> <?= e(percent_br(abs($deltaReceita))) ?> vs <?= e($mesAnt['label']) ?>
          </span>
        </div>
      </article>
      <article class="fin-kpi out">
        <div class="fin-kpi-label">Despesas / Saídas</div>
        <div class="fin-kpi-value"><?= e(money_br($t['totalDespesas'])) ?></div>
        <div class="fin-kpi-meta">
          <?= (int) $c['despesas'] ?> saídas
          <span class="delta <?= $deltaDespesa <= 0 ? 'up' : 'down' ?>">
            <?= $deltaDespesa >= 0 ? '▲' : '▼' ?> <?= e(percent_br(abs($deltaDespesa))) ?> vs <?= e($mesAnt['label']) ?>
          </span>
        </div>
      </article>
      <article class="fin-kpi bal">
        <div class="fin-kpi-label">Saldo líquido</div>
        <div class="fin-kpi-value"><?= e(money_br($t['saldo'])) ?></div>
        <div class="fin-kpi-meta">Entradas − saídas · margem <?= e(percent_br($margem)) ?></div>
      </article>
      <article class="fin-kpi cash">
        <div class="fin-kpi-label">Caixa (contas)</div>
        <div class="fin-kpi-value"><?= e(money_br($saldoBancos)) ?></div>
        <div class="fin-kpi-meta"><?= (int) $c['contas'] ?>/<?= (int) MAX_BANK_ACCOUNTS ?> contas ativas</div>
      </article>
      <article class="fin-kpi warn">
        <div class="fin-kpi-label">Orçamento consumido</div>
        <div class="fin-kpi-value"><?= e(percent_br($t['percentualGasto'])) ?></div>
        <div class="progress-track" style="margin-top:.45rem"><div class="progress-fill" style="width:<?= min(100, $t['percentualGasto'] * 100) ?>%"></div></div>
        <div class="fin-kpi-meta">de <?= e(money_br($t['orcamento'])) ?></div>
      </article>
      <article class="fin-kpi <?= $vf['withinLimit'] ? 'warn' : 'out' ?>">
        <div class="fin-kpi-label">Veículos + combustíveis</div>
        <div class="fin-kpi-value" style="font-size:1.35rem"><?= e(money_br($vf['amount'])) ?></div>
        <div class="progress-track" style="margin-top:.45rem"><div class="progress-fill" style="width:<?= min(100, $vf['limit'] > 0 ? ($vf['amount'] / $vf['limit']) * 100 : 0) ?>%;background:<?= $vf['withinLimit'] ? 'linear-gradient(90deg,#f59e0b,#fbbf24)' : 'linear-gradient(90deg,#dc2626,#f87171)' ?>"></div></div>
        <div class="fin-kpi-meta">Teto 20% · <?= e(money_br($vf['limit'])) ?></div>
      </article>
      <article class="fin-kpi <?= (int) $c['pending'] > 0 ? 'out' : 'bal' ?>">
        <div class="fin-kpi-label">Pendências (conciliação)</div>
        <div class="fin-kpi-value"><?= (int) $c['pending'] ?></div>
        <div class="fin-kpi-meta"><?= (int) $c['conciliated'] ?> conciliados · <?= (int) $c['divergent'] ?> divergentes</div>
      </article>
      <article class="fin-kpi bal">
        <div class="fin-kpi-label">Saldo do mês <?= e($mesAtual['label']) ?></div>
        <div class="fin-kpi-value" style="font-size:1.35rem"><?= e(money_br($mesAtual['saldo'])) ?></div>
        <div class="fin-kpi-meta">+<?= e(money_br($mesAtual['entrada'])) ?> / −<?= e(money_br($mesAtual['saida'])) ?></div>
      </article>
    </section>
  </div>

  <!-- 2. ANÁLISES COMPARATIVAS -->
  <div class="fin-zone">
    <div class="fin-zone-label"><span>2</span> Análises comparativas</div>
    <section class="grid grid-2" style="margin-bottom:1rem">
      <div class="panel dash-panel-3d tone-flow">
        <h2 class="dash-section-title">Fluxo de caixa — evolução mensal</h2>
        <p class="muted" style="margin:-.35rem 0 .75rem;font-size:.82rem">Barras: entradas (verde) × saídas (vermelho) nos últimos 6 meses.</p>
        <div class="col-chart" role="img" aria-label="Gráfico de barras do fluxo de caixa">
          <svg viewBox="0 0 100 <?= $chartH ?>" preserveAspectRatio="none" class="col-chart-svg">
            <?php foreach ($cashFlow as $i => $cf):
              $hIn = $maxFlow > 0 ? (($cf['entrada'] / $maxFlow) * ($chartH - $chartPad - 8)) : 0;
              $hOut = $maxFlow > 0 ? (($cf['saida'] / $maxFlow) * ($chartH - $chartPad - 8)) : 0;
              $x = $i * $slot + $slot * 0.18;
              $bw = $slot * 0.28;
              $base = $chartH - $chartPad;
            ?>
              <rect class="col-in" x="<?= $x ?>" y="<?= $base - $hIn ?>" width="<?= $bw ?>" height="<?= max(0.4, $hIn) ?>" rx="0.8"></rect>
              <rect class="col-out" x="<?= $x + $bw + 1.2 ?>" y="<?= $base - $hOut ?>" width="<?= $bw ?>" height="<?= max(0.4, $hOut) ?>" rx="0.8"></rect>
            <?php endforeach; ?>
            <line x1="0" y1="<?= $chartH - $chartPad ?>" x2="100" y2="<?= $chartH - $chartPad ?>" class="col-axis"></line>
          </svg>
          <div class="col-chart-labels">
            <?php foreach ($cashFlow as $cf): ?><span><?= e($cf['label']) ?></span><?php endforeach; ?>
          </div>
        </div>
        <div class="chart-legend">
          <span><i class="lg-in"></i> Entradas</span>
          <span><i class="lg-out"></i> Saídas</span>
        </div>
      </div>

      <div class="panel dash-panel-3d tone-src">
        <h2 class="dash-section-title">Receitas por fonte (proporção)</h2>
        <p class="muted" style="margin:-.35rem 0 .75rem;font-size:.82rem">Distribuição do faturamento — Doador PF, Fundo e Vaquinha.</p>
        <div class="donut-wrap">
          <svg class="donut-svg" viewBox="0 0 42 42" aria-hidden="true">
            <?php
              $r = 15.5; $cLen = 2 * M_PI * $r; $offset = 0;
              foreach ($donut as $slice):
                $len = max(0.01, $slice['share'] * $cLen);
            ?>
              <circle cx="21" cy="21" r="<?= $r ?>" fill="none"
                stroke="<?= e($slice['color']) ?>" stroke-width="7"
                stroke-dasharray="<?= $len ?> <?= max(0.01, $cLen - $len) ?>"
                stroke-dashoffset="<?= -$offset ?>"
                transform="rotate(-90 21 21)"></circle>
            <?php $offset += $len; endforeach; ?>
            <circle cx="21" cy="21" r="10.5" fill="#fff"></circle>
            <text x="21" y="20.5" text-anchor="middle" class="donut-center-label">Receitas</text>
            <text x="21" y="25.2" text-anchor="middle" class="donut-center-val"><?= e(percent_br($t['percentualRecebido'], 0)) ?></text>
          </svg>
          <div class="pie-legend" style="flex:1;margin:0">
            <?php foreach ($metrics['receitasPorFonte'] as $row): ?>
              <div class="pie-legend-item">
                <span style="display:flex;align-items:center;gap:.45rem">
                  <span class="pie-dot" style="background:<?= e(REVENUE_SOURCE_COLORS[$row['source']] ?? '#0f766e') ?>"></span>
                  <?= e($row['label']) ?>
                </span>
                <strong><?= e(money_br($row['amount'])) ?> · <?= e(percent_br((float) ($row['share'] ?? 0))) ?></strong>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </section>

    <section class="panel dash-panel-3d tone-cat" style="margin-bottom:1rem">
      <div class="row-actions" style="justify-content:space-between;margin-bottom:.35rem">
        <div>
          <h2 class="dash-section-title" style="margin:0">Ranking de despesas por categoria</h2>
          <p class="muted" style="margin:.25rem 0 0;font-size:.82rem">Onde o dinheiro está saindo — maior para menor.</p>
        </div>
        <a class="btn btn-secondary" href="<?= e(url_path('admin/despesas.php')) ?>">Ver despesas</a>
      </div>
      <?php if (!$ranking): ?>
        <div class="empty">Nenhuma despesa lançada ainda.</div>
      <?php else: ?>
        <div class="rank-list">
          <?php foreach ($ranking as $row): ?>
            <div class="rank-row">
              <div class="rank-pos">#<?= (int) $row['rank'] ?></div>
              <div class="rank-body">
                <div class="rank-head">
                  <strong><?= e($row['label']) ?></strong>
                  <span class="muted"><?= (int) $row['count'] ?> lanç. · <?= e(percent_br((float) $row['share'])) ?></span>
                  <strong class="rank-val"><?= e(money_br($row['amount'])) ?></strong>
                </div>
                <div class="bar-track rank-bar"><div class="bar-fill" style="width:<?= ($row['amount'] / $maxRank) * 100 ?>%;background:<?= e($row['color']) ?>"></div></div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>
  </div>

  <!-- 3. DETALHES -->
  <div class="fin-zone">
    <div class="fin-zone-label"><span>3</span> Detalhes e atenção</div>

    <section class="grid grid-3" style="margin-bottom:1rem">
      <div class="fin-attention <?= (int) $c['pending'] > 0 ? 'is-alert' : 'is-ok' ?>">
        <div class="l">Pendências de conciliação</div>
        <div class="n"><?= (int) $c['pending'] ?></div>
        <a href="<?= e(url_path('admin/conciliacao.php')) ?>">Abrir conciliação →</a>
      </div>
      <div class="fin-attention <?= (int) $c['nfeInvalid'] > 0 ? 'is-alert' : 'is-ok' ?>">
        <div class="l">NF-e inválidas / sem chave</div>
        <div class="n"><?= (int) $c['nfeInvalid'] + (int) $c['nfeMissing'] ?></div>
        <a href="<?= e(url_path('admin/despesas.php')) ?>">Revisar despesas →</a>
      </div>
      <div class="fin-attention <?= $vf['withinLimit'] ? 'is-ok' : 'is-alert' ?>">
        <div class="l">Limite 20% veículos+combustível</div>
        <div class="n" style="font-size:1.4rem"><?= e(percent_br($vf['ratio'])) ?></div>
        <span class="muted" style="font-size:.8rem"><?= $vf['withinLimit'] ? 'Dentro do teto' : 'Acima do teto legal' ?></span>
      </div>
    </section>

    <section class="grid grid-2" style="margin-bottom:1rem">
      <div class="panel dash-panel-3d tone-bank">
        <div class="row-actions" style="justify-content:space-between">
          <h2 class="dash-section-title" style="margin:0">Saldos das contas</h2>
          <a href="<?= e(url_path('admin/contas.php')) ?>">Contas →</a>
        </div>
        <div class="stack" style="margin-top:.85rem">
          <?php foreach ($metrics['bankBalances'] as $i => $b): ?>
            <div class="bank-3d">
              <div>
                <div class="muted" style="font-size:.72rem">Conta <?= $i + 1 ?></div>
                <strong><?= e($b['label']) ?></strong>
                <div class="muted" style="font-size:.78rem"><?= e($b['bankName']) ?> · <?= e($b['agency']) ?></div>
              </div>
              <div class="bal"><?= e(money_br($b['balance'])) ?></div>
            </div>
          <?php endforeach; ?>
          <?php if (!$metrics['bankBalances']): ?><div class="empty">Nenhuma conta.</div><?php endif; ?>
        </div>
      </div>
      <div class="panel dash-panel-3d">
        <h2 class="dash-section-title">Indicadores operacionais</h2>
        <div class="stat-strip" style="grid-template-columns:repeat(2,minmax(0,1fr));margin:0">
          <div class="stat-chip tone-green"><div class="l">Doadores PF</div><div class="n"><?= (int) $c['doadores'] ?></div></div>
          <div class="stat-chip tone-blue"><div class="l">Cabos</div><div class="n"><?= (int) $c['cabos'] ?></div></div>
          <div class="stat-chip tone-teal"><div class="l">Contratos</div><div class="n"><?= (int) $c['contratosAtivos'] ?></div></div>
          <div class="stat-chip tone-cyan"><div class="l">NF-e válidas</div><div class="n"><?= (int) $c['nfeValid'] ?></div></div>
        </div>
      </div>
    </section>

    <section class="panel table-wrap dash-table-wrap">
      <div class="row-actions" style="justify-content:space-between;margin-bottom:.75rem">
        <div>
          <h2 class="dash-section-title" style="margin:0">Últimas movimentações</h2>
          <p class="muted" style="margin:.2rem 0 0;font-size:.82rem">Detalhe do que entrou e saiu recentemente.</p>
        </div>
        <a class="btn btn-secondary" href="<?= e(url_path('admin/movimentacoes.php')) ?>">Tela completa</a>
      </div>
      <table class="data">
        <thead>
          <tr><th>Data</th><th>Tipo</th><th>Origem / Destino</th><th>Detalhe</th><th>Conta</th><th>Valor</th></tr>
        </thead>
        <tbody>
        <?php if (!$recent): ?>
          <tr><td colspan="6" class="empty">Sem movimentações lançadas.</td></tr>
        <?php endif; ?>
        <?php foreach ($recent as $m): ?>
          <?php
            $isIn = $m['kind'] === 'ENTRADA';
            $codeLabel = $isIn
              ? (REVENUE_SOURCES[$m['code']] ?? $m['code'])
              : (EXPENSE_CATEGORIES[$m['code']] ?? $m['code']);
          ?>
          <tr>
            <td><?= e(date_br($m['movDate'])) ?></td>
            <td><span class="badge <?= $isIn ? 'badge-ok' : 'badge-danger' ?>"><?= $isIn ? 'Entrada' : 'Saída' ?></span></td>
            <td><?= e($m['party'] ?: $codeLabel) ?><div class="muted" style="font-size:.72rem"><?= e($codeLabel) ?></div></td>
            <td><?= e(mb_strimwidth((string) ($m['detail'] ?? ''), 0, 48, '…')) ?></td>
            <td><?= e($m['accountLabel'] ?: '—') ?></td>
            <td class="<?= $isIn ? 'mov-in' : 'mov-out' ?>"><?= $isIn ? '+' : '−' ?><?= e(money_br($m['amount'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </section>
  </div>
<?php endif; ?>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
