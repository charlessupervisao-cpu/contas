<?php
require_once dirname(__DIR__) . '/bootstrap.php';
$user = Auth::requireLogin('receitas');
$activeModule = 'receitas';
$pageTitle = 'Receitas';
$pdo = Database::pdo();
$rows = $pdo->query(
    'SELECT r.*, a.label AS accountLabel FROM `Revenue` r
     LEFT JOIN `BankAccount` a ON a.id = r.bankAccountId
     ORDER BY r.date DESC'
)->fetchAll();
$total = array_sum(array_map(fn ($r) => (float) $r['amount'], $rows));
$bySource = [];
foreach (REVENUE_SOURCES as $code => $label) {
    $items = array_values(array_filter($rows, fn ($r) => $r['source'] === $code));
    $bySource[] = [
        'code' => $code,
        'label' => $label,
        'count' => count($items),
        'amount' => array_sum(array_map(fn ($r) => (float) $r['amount'], $items)),
        'color' => REVENUE_SOURCE_COLORS[$code],
    ];
}
$donors = [];
foreach ($rows as $r) {
    if ($r['source'] === 'DOADOR_PF' && $r['donorCpf']) {
        $donors[$r['donorCpf']] = true;
    }
}
require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<div class="row-actions" style="margin-bottom:1rem;justify-content:space-between">
  <div class="muted">
    Total: <strong><?= e(money_br($total)) ?></strong> ·
    <?= count($rows) ?> registros ·
    <?= count($donors) ?> doadores PF distintos
  </div>
  <?php if (can_launch($user['role'])): ?>
    <a class="btn btn-primary" href="<?= e(url_path('admin/lancamento.php?tipo=RECEITA')) ?>">Nova receita <span class="kbd">F2</span></a>
  <?php endif; ?>
</div>

<div class="grid grid-3" style="margin-bottom:1rem">
  <?php foreach ($bySource as $s): ?>
    <div class="panel kpi">
      <div class="muted"><?= e($s['label']) ?></div>
      <div class="display" style="font-size:1.4rem;color:<?= e($s['color']) ?>"><?= e(money_br($s['amount'])) ?></div>
      <div class="muted"><?= (int) $s['count'] ?> lançamentos · <?= $total > 0 ? e(percent_br($s['amount'] / $total)) : '0%' ?> do total</div>
    </div>
  <?php endforeach; ?>
</div>

<div class="panel table-wrap">
<table class="data">
  <thead><tr><th>Data</th><th>Fonte</th><th>Doador / Origem</th><th>CPF</th><th>Conta</th><th>Valor</th></tr></thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="6" class="empty">Nenhuma receita.</td></tr><?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e(date_br($r['date'])) ?></td>
      <td><?= e(REVENUE_SOURCES[$r['source']] ?? $r['source']) ?></td>
      <td><?= e($r['donorName'] ?: '—') ?><div class="muted" style="font-size:.75rem"><?= e($r['description'] ?: '') ?></div></td>
      <td><?= e($r['donorCpf'] ?: '—') ?></td>
      <td><?= e($r['accountLabel'] ?: '—') ?></td>
      <td><strong><?= e(money_br($r['amount'])) ?></strong></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
