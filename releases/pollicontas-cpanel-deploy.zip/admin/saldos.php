<?php
require_once dirname(__DIR__) . '/bootstrap.php';
$user = Auth::requireLogin('saldos');
$activeModule = 'saldos';
$pageTitle = 'Ajuste de Saldos';
$campaign = Metrics::getCampaign();
$pdo = Database::pdo();
$accounts = $campaign ? Lancamento::listAccountsOrdered($campaign['id']) : [];

if (request_method() === 'POST') {
    Auth::requireMaster();
    $bankAccountId = (string) post('bankAccountId');
    $newBalance = (float) post('newBalance');
    $reason = trim((string) post('reason', 'Ajuste manual de saldo'));
    $notes = trim((string) post('notes', ''));
    $acc = null;
    foreach ($accounts as $a) if ($a['id'] === $bankAccountId) $acc = $a;
    if (!$acc) {
        flash_set('danger', 'Conta inválida.');
        redirect('/admin/saldos.php');
    }
    $prev = (float) $acc['balance'];
    $diff = $newBalance - $prev;
    $now = now_sql();
    $date = parse_date_input((string) post('date'));
    try {
        $pdo->beginTransaction();
        $pdo->prepare('UPDATE `BankAccount` SET balance=?, updatedAt=? WHERE id=?')->execute([$newBalance, $now, $bankAccountId]);
        $pdo->prepare(
            'INSERT INTO `BalanceAdjustment` (id, bankAccountId, previousBalance, newBalance, difference, date, reason, notes, createdById, createdAt)
             VALUES (?,?,?,?,?,?,?,?,?,?)'
        )->execute([cuid(), $bankAccountId, $prev, $newBalance, $diff, $date, $reason, $notes ?: null, $user['id'], $now]);
        $pdo->prepare(
            'INSERT INTO `BankTransaction` (id, bankAccountId, date, description, amount, type, status, createdAt, updatedAt)
             VALUES (?,?,?,?,?,?,?,?,?)'
        )->execute([
            cuid(), $bankAccountId, $date, 'Ajuste de saldo — ' . $reason, $diff,
            $diff >= 0 ? 'AJUSTE_CREDITO' : 'AJUSTE_DEBITO', 'CONCILIADO', $now, $now,
        ]);
        $pdo->prepare('INSERT INTO `AuditLog` (id,userId,action,entity,details,createdAt) VALUES (?,?,?,?,?,?)')
            ->execute([cuid(), $user['id'], 'BALANCE_ADJUST', 'BankAccount', sprintf('%s: %.2f → %.2f', $acc['label'], $prev, $newBalance), $now]);
        $pdo->commit();
        flash_set('ok', 'Saldo ajustado.');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash_set('danger', $e->getMessage());
    }
    redirect('/admin/saldos.php');
}

$adjustments = $pdo->query(
    'SELECT b.*, a.label AS accountLabel FROM `BalanceAdjustment` b
     LEFT JOIN `BankAccount` a ON a.id = b.bankAccountId
     ORDER BY b.createdAt DESC LIMIT 50'
)->fetchAll();
require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<div class="grid grid-2">
  <div class="panel form-card">
    <h3 class="display" style="margin-top:0">Ajustar saldo</h3>
    <?php if (!can_launch($user['role'])): ?>
      <div class="alert alert-warn">Somente Master pode ajustar.</div>
    <?php else: ?>
    <form method="post">
      <div class="field">
        <label class="label">Conta</label>
        <select class="select" name="bankAccountId" required>
          <?php foreach ($accounts as $a): ?>
            <option value="<?= e($a['id']) ?>"><?= e($a['label']) ?> — <?= e(money_br($a['balance'])) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field"><label class="label">Novo saldo</label><input class="input" type="number" step="0.01" name="newBalance" required></div>
      <div class="field"><label class="label">Data</label><input class="input" type="date" name="date" value="<?= e(date('Y-m-d')) ?>"></div>
      <div class="field"><label class="label">Motivo</label><input class="input" name="reason" required value="Ajuste conforme extrato"></div>
      <div class="field"><label class="label">Observações</label><textarea class="textarea" name="notes"></textarea></div>
      <button class="btn btn-primary" type="submit">Salvar ajuste</button>
    </form>
    <?php endif; ?>
  </div>
  <div class="panel table-wrap">
    <h3 class="display" style="margin-top:0">Histórico</h3>
    <table class="data">
      <thead><tr><th>Data</th><th>Conta</th><th>De → Para</th><th>Diferença</th></tr></thead>
      <tbody>
      <?php foreach ($adjustments as $b): ?>
        <tr>
          <td><?= e(datetime_br($b['date'])) ?></td>
          <td><?= e($b['accountLabel']) ?></td>
          <td><?= e(money_br($b['previousBalance'])) ?> → <?= e(money_br($b['newBalance'])) ?></td>
          <td><?= e(money_br($b['difference'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
