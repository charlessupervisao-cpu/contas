<?php
require_once dirname(__DIR__) . '/bootstrap.php';
$user = Auth::requireLogin('wizard');
$activeModule = 'wizard';
$pageTitle = 'Wizard de dados';
$campaign = Metrics::getCampaign();
$pdo = Database::pdo();

if (request_method() === 'POST') {
    Auth::requireMaster();
    if (!$campaign) {
        flash_set('danger', 'Campanha não encontrada.');
        redirect('/admin/wizard.php');
    }
    $now = now_sql();
    $photoPath = $campaign['photoUrl'] ?? null;

    try {
        if (!empty(post('remove_photo'))) {
            PhotoUpload::deletePrevious($photoPath);
            $photoPath = null;
        }
        if (!empty($_FILES['photo']['name'])) {
            $saved = PhotoUpload::saveCandidatePhoto($_FILES['photo'], (string) $campaign['id'], $photoPath);
            if ($saved) {
                $photoPath = $saved;
            }
        }

        $pdo->prepare(
            'UPDATE `Campaign` SET candidateName=?, candidateFullName=?, candidateNumber=?, party=?, partyNumber=?, office=?, totalBudget=?, legalSpendLimit=?, website=?, situation=?, reelection=?, photoUrl=?, updatedAt=? WHERE id=?'
        )->execute([
            trim((string) post('candidateName')),
            trim((string) post('candidateFullName')),
            trim((string) post('candidateNumber')),
            trim((string) post('party')),
            trim((string) post('partyNumber')),
            trim((string) post('office', 'Deputado Estadual')),
            (float) post('totalBudget'),
            (float) post('legalSpendLimit'),
            post('website') ?: null,
            trim((string) post('situation', 'Em campanha')),
            post('reelection') ? 1 : 0,
            $photoPath,
            $now,
            $campaign['id'],
        ]);
        flash_set('ok', 'Campanha e foto atualizadas.');
    } catch (Throwable $e) {
        flash_set('danger', $e->getMessage());
    }
    redirect('/admin/wizard.php');
}

$status = Demo::wizardStatus();
$steps = [
    ['campanha', 'Campanha + foto', '/admin/wizard.php', true],
    ['contas', 'Contas bancárias', '/admin/contas.php', true],
    ['vinculos', 'Vínculos', '/admin/vinculos.php', true],
    ['fornecedores', 'Fornecedores', '/admin/fornecedores.php', true],
    ['veiculos', 'Veículos', '/admin/veiculos.php', false],
    ['cabos', 'Cabos', '/admin/cabos.php', false],
    ['receitas', 'Receitas / Despesas', '/admin/lancamento.php', true],
];
$photoUrl = !empty($campaign['photoUrl']) ? url_path(ltrim((string) $campaign['photoUrl'], '/')) : '';
require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<div class="grid grid-2">
  <div class="panel">
    <h3 class="display" style="margin-top:0">Progresso</h3>
    <?php foreach ($steps as [$key,$label,$href,$required]): ?>
      <?php $done = ($status[$key] ?? 0) > 0 || ($key==='campanha' && ($status['campanha']??0)>0); ?>
      <div class="row-actions" style="justify-content:space-between;padding:.55rem 0;border-bottom:1px solid var(--line)">
        <div>
          <strong><?= e($label) ?></strong>
          <?= $required ? '<span class="badge badge-info">obrigatório</span>' : '<span class="badge badge-warn">opcional</span>' ?>
        </div>
        <div class="row-actions">
          <span class="badge <?= $done?'badge-ok':'badge-warn' ?>"><?= $done?'ok':'pendente' ?></span>
          <a class="btn btn-ghost" href="<?= e(url_path(ltrim($href,'/'))) ?>">Abrir</a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="panel form-card">
    <h3 class="display" style="margin-top:0">Dados da campanha</h3>
    <form method="post" enctype="multipart/form-data">
      <div class="field">
        <label class="label">Foto do deputado (página inicial)</label>
        <div class="photo-upload-box">
          <div class="candidate-photo-frame preview">
            <?php if ($photoUrl): ?>
              <img src="<?= e($photoUrl) ?>" alt="Foto do deputado" width="180" height="240">
            <?php else: ?>
              <span class="photo-placeholder">Sem foto</span>
            <?php endif; ?>
          </div>
          <div>
            <input class="input" type="file" name="photo" accept="image/jpeg,image/png,image/webp">
            <p class="muted" style="font-size:.8rem;margin:.55rem 0 0">
              Retrato <strong>3∶4</strong> · tamanho ideal <strong>600 × 800 px</strong> · JPG/PNG/WebP · máx. 2,5&nbsp;MB.<br>
              A imagem é cortada ao centro e salva em 600×800 para a home.
            </p>
            <?php if ($photoUrl): ?>
              <label class="row-actions" style="margin-top:.55rem">
                <input type="checkbox" name="remove_photo" value="1"> Remover foto atual
              </label>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <div class="field"><label class="label">Nome urna</label><input class="input" name="candidateName" value="<?= e($campaign['candidateName'] ?? '') ?>" required></div>
      <div class="field"><label class="label">Nome completo</label><input class="input" name="candidateFullName" value="<?= e($campaign['candidateFullName'] ?? '') ?>" required></div>
      <div class="grid grid-2">
        <div class="field"><label class="label">Número</label><input class="input" name="candidateNumber" value="<?= e($campaign['candidateNumber'] ?? '') ?>" required></div>
        <div class="field"><label class="label">Partido</label><input class="input" name="party" value="<?= e($campaign['party'] ?? '') ?>" required></div>
      </div>
      <div class="grid grid-2">
        <div class="field"><label class="label">Nº partido</label><input class="input" name="partyNumber" value="<?= e($campaign['partyNumber'] ?? '') ?>"></div>
        <div class="field"><label class="label">Cargo</label><input class="input" name="office" value="<?= e($campaign['office'] ?? 'Deputado Estadual') ?>"></div>
      </div>
      <div class="grid grid-2">
        <div class="field"><label class="label">Orçamento</label><input class="input" type="number" step="0.01" name="totalBudget" value="<?= e((string)($campaign['totalBudget'] ?? 0)) ?>" required></div>
        <div class="field"><label class="label">Limite legal</label><input class="input" type="number" step="0.01" name="legalSpendLimit" value="<?= e((string)($campaign['legalSpendLimit'] ?? 0)) ?>" required></div>
      </div>
      <div class="field"><label class="label">Site de campanha (interno)</label><input class="input" name="website" value="<?= e($campaign['website'] ?? '') ?>" placeholder="opcional"></div>
      <div class="field"><label class="label">Situação</label><input class="input" name="situation" value="<?= e($campaign['situation'] ?? '') ?>"></div>
      <label class="row-actions"><input type="checkbox" name="reelection" value="1" <?= !empty($campaign['reelection'])?'checked':'' ?>> Reeleição</label>
      <div style="margin-top:1rem"><button class="btn btn-primary" type="submit">Salvar campanha</button></div>
    </form>
  </div>
</div>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
