<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/bootstrap.php';

$user = Auth::requireLogin('fornecedores');
$activeModule = 'fornecedores';
$pageTitle = 'Fornecedores';
$campaign = Metrics::getCampaign();
$pdo = Database::pdo();
$canWrite = can_launch($user['role']);
$errors = [];
$editId = trim((string) get('id', ''));
$edit = null;

if ($editId !== '' && $campaign) {
    $st = $pdo->prepare('SELECT * FROM `Supplier` WHERE id = ? AND campaignId = ? LIMIT 1');
    $st->execute([$editId, $campaign['id']]);
    $edit = $st->fetch() ?: null;
}

if (request_method() === 'POST' && $canWrite) {
    Auth::requireMaster();
    $action = (string) post('action', 'save');
    $now = now_sql();

    if ($action === 'import_csv_nfe' || $action === 'replace_tse' || $action === 'import_tse') {
        if (!$campaign) {
            flash_set('danger', 'Campanha não encontrada.');
            redirect('/admin/fornecedores.php');
        }
        // Fonte principal: CSV da aba NF-es do DivulgaCandContas (todos os campos)
        $result = TseNfeCsv::replaceFromCsv((string) $campaign['id']);
        if (!empty($result['error'])) {
            flash_set('danger', $result['error']);
        } else {
            flash_set(
                'ok',
                sprintf(
                    'CSV NF-es importado: apagados %d fornecedores · %d emitentes · %d notas com todos os campos (CNPJ, natureza, modelo, série, chave, link…).',
                    (int) $result['deletedSuppliers'],
                    (int) $result['suppliers'],
                    (int) $result['nfes']
                )
            );
        }
        redirect('/admin/fornecedores.php');
    }

    if ($action === 'delete') {
        $id = (string) post('id');
        $pdo->prepare('DELETE FROM `Supplier` WHERE id = ? AND campaignId = ?')->execute([$id, $campaign['id'] ?? '']);
        flash_set('ok', 'Fornecedor removido.');
        redirect('/admin/fornecedores.php');
    }

    if ($action === 'save') {
        $id = trim((string) post('id', ''));
        $documentType = trim((string) post('documentType', 'CNPJ'));
        if (!in_array($documentType, ['CNPJ', 'CPF'], true)) {
            $documentType = 'CNPJ';
        }
        $document = format_cpf_cnpj((string) post('document', ''));
        $name = trim((string) post('name', ''));
        $tradeName = trim((string) post('tradeName', ''));
        $email = trim((string) post('email', ''));
        $phone = trim((string) post('phone', ''));
        $contactName = trim((string) post('contactName', ''));
        $zipCode = trim((string) post('zipCode', ''));
        $address = trim((string) post('address', ''));
        $addressNumber = trim((string) post('addressNumber', ''));
        $addressComplement = trim((string) post('addressComplement', ''));
        $neighborhood = trim((string) post('neighborhood', ''));
        $city = trim((string) post('city', ''));
        $state = strtoupper(trim((string) post('state', '')));
        $stateRegistration = trim((string) post('stateRegistration', ''));
        $municipalRegistration = trim((string) post('municipalRegistration', ''));
        $category = trim((string) post('category', ''));
        $notes = trim((string) post('notes', ''));

        if ($name === '') {
            $errors[] = 'Informe a razão social / nome do fornecedor.';
        }
        if ($documentType === 'CNPJ' && !is_valid_cnpj($document)) {
            $errors[] = 'CNPJ inválido.';
        }
        if ($documentType === 'CPF' && !is_valid_cpf($document)) {
            $errors[] = 'CPF inválido.';
        }
        if ($state !== '' && !preg_match('/^[A-Z]{2}$/', $state)) {
            $errors[] = 'UF inválida.';
        }

        if (!$errors && $campaign) {
            $params = [
                $documentType,
                $document !== '' ? $document : null,
                $name,
                $tradeName !== '' ? $tradeName : null,
                $email !== '' ? $email : null,
                $phone !== '' ? $phone : null,
                $contactName !== '' ? $contactName : null,
                $zipCode !== '' ? $zipCode : null,
                $address !== '' ? $address : null,
                $addressNumber !== '' ? $addressNumber : null,
                $addressComplement !== '' ? $addressComplement : null,
                $neighborhood !== '' ? $neighborhood : null,
                $city !== '' ? $city : null,
                $state !== '' ? $state : null,
                $stateRegistration !== '' ? $stateRegistration : null,
                $municipalRegistration !== '' ? $municipalRegistration : null,
                $category !== '' ? $category : null,
                $notes !== '' ? $notes : null,
                $now,
            ];

            if ($id !== '') {
                $pdo->prepare(
                    'UPDATE `Supplier` SET documentType=?, document=?, name=?, tradeName=?, email=?, phone=?, contactName=?,
                     zipCode=?, address=?, addressNumber=?, addressComplement=?, neighborhood=?, city=?, state=?,
                     stateRegistration=?, municipalRegistration=?, category=?, notes=?, updatedAt=?
                     WHERE id=? AND campaignId=?'
                )->execute([...$params, $id, $campaign['id']]);
                flash_set('ok', 'Fornecedor atualizado (campos fiscais TSE / NF-e).');
            } else {
                $pdo->prepare(
                    'INSERT INTO `Supplier` (
                        id, campaignId, documentType, document, name, tradeName, email, phone, contactName,
                        zipCode, address, addressNumber, addressComplement, neighborhood, city, state,
                        stateRegistration, municipalRegistration, category, notes, active, createdAt, updatedAt
                     ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)'
                )->execute([cuid(), $campaign['id'], ...array_slice($params, 0, 18), $now, $now]);
                flash_set('ok', 'Fornecedor cadastrado.');
            }
            redirect('/admin/fornecedores.php');
        }
    }
}

$rows = [];
$totalNfes = 0;
if ($campaign) {
    $st = $pdo->prepare(
        "SELECT s.*,
                COUNT(n.id) AS qtd,
                COALESCE(SUM(n.valor), 0) AS valor
         FROM `Supplier` s
         LEFT JOIN `SupplierNfe` n ON n.supplierId = s.id
         WHERE s.campaignId = ?
         GROUP BY s.id
         ORDER BY valor DESC, s.name ASC"
    );
    $st->execute([$campaign['id']]);
    $rows = $st->fetchAll();
    $cnt = $pdo->prepare('SELECT COUNT(*) AS c FROM `SupplierNfe` WHERE campaignId = ?');
    $cnt->execute([$campaign['id']]);
    $totalNfes = (int) $cnt->fetch()['c'];
}

$totalValor = array_sum(array_map(static fn ($r) => (float) $r['valor'], $rows));
$totalQtd = (int) array_sum(array_map(static fn ($r) => (int) $r['qtd'], $rows));

require dirname(__DIR__) . '/templates/admin_layout_start.php';
?>
<div class="panel" style="margin-bottom:1rem">
  <div class="row-actions" style="justify-content:space-between;align-items:flex-start;gap:1rem;flex-wrap:wrap">
    <div>
      <h2 class="display" style="margin:0">Fornecedores</h2>
      <p class="muted" style="margin:.35rem 0 0">
        Emitentes da aba NF-es do DivulgaCandContas — <strong>CNPJ</strong>, nome, natureza, modelo, data, nº NF/série, valor, UE, chave e link.
      </p>
    </div>
    <?php if ($canWrite): ?>
      <div class="row-actions">
        <form method="post" onsubmit="return confirm('Apagar TODOS os fornecedores/NF-es atuais e importar o CSV oficial da aba NF-es do TSE?');">
          <input type="hidden" name="action" value="import_csv_nfe">
          <button class="btn btn-primary" type="submit">Importar CSV NF-es (apaga atuais)</button>
        </form>
        <a class="btn btn-secondary" href="#form-fornecedor"><?= $edit ? 'Editar formulário' : 'Novo fornecedor' ?></a>
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="grid grid-4" style="margin-bottom:1rem">
  <div class="stat-chip"><div class="l">Emitentes</div><div class="n"><?= count($rows) ?></div></div>
  <div class="stat-chip"><div class="l">Notas (CSV)</div><div class="n"><?= number_format($totalNfes ?: $totalQtd, 0, ',', '.') ?></div></div>
  <div class="stat-chip"><div class="l">Valor total</div><div class="n" style="font-size:1.1rem"><?= e(money_br($totalValor)) ?></div></div>
  <div class="stat-chip"><div class="l">Referência TSE</div><div class="n" style="font-size:.85rem;line-height:1.3">GO 2022 · NF-es</div></div>
</div>

<div class="panel table-wrap">
  <table class="data">
    <thead>
      <tr>
        <th>Nome</th>
        <th>CPF/CNPJ</th>
        <th>Qtd</th>
        <th>Valor</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
    <?php if (!$rows): ?>
      <tr><td colspan="5" class="empty">Nenhum fornecedor. Use “Sincronizar TSE” para puxar os prestadores da prestação de contas.</td></tr>
    <?php endif; ?>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td>
          <strong><?= e((string) $r['name']) ?></strong>
          <?php if (!empty($r['tradeName'])): ?>
            <div class="muted" style="font-size:.82rem"><?= e((string) $r['tradeName']) ?></div>
          <?php endif; ?>
          <?php if (!empty($r['city']) || !empty($r['state'])): ?>
            <div class="muted" style="font-size:.78rem">
              <?= e(trim((string) ($r['city'] ?? '') . ($r['state'] ? ' / ' . $r['state'] : ''))) ?>
            </div>
          <?php endif; ?>
          <?php if (!empty($r['category'])): ?>
            <div class="muted" style="font-size:.75rem"><?= e((string) $r['category']) ?></div>
          <?php endif; ?>
        </td>
        <td><?= e((string) ($r['document'] ?: '—')) ?></td>
        <td><?= (int) $r['qtd'] ?></td>
        <td><?= e(money_br((float) $r['valor'])) ?></td>
        <td>
          <div class="row-actions">
            <a class="btn btn-ghost" href="<?= e(url_path('admin/fornecedores/ver.php?id=' . rawurlencode((string) $r['id']))) ?>">Ver</a>
            <?php if ($canWrite): ?>
              <a class="btn btn-ghost" href="<?= e(url_path('admin/fornecedores.php?id=' . rawurlencode((string) $r['id']))) ?>#form-fornecedor">Editar</a>
              <form method="post" onsubmit="return confirm('Excluir este fornecedor?');">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= e((string) $r['id']) ?>">
                <button class="btn btn-danger" type="submit">Excluir</button>
              </form>
            <?php endif; ?>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php if ($canWrite): ?>
<div class="panel form-card" id="form-fornecedor" style="margin-top:1rem">
  <h3 class="display" style="margin-top:0"><?= $edit ? 'Editar fornecedor' : 'Cadastrar fornecedor' ?></h3>
  <p class="muted">Campos do emitente da NF-e / prestador TSE: razão social, fantasia, CPF/CNPJ, endereço, IE e IM.</p>

  <?php if ($errors): ?>
    <div class="alert alert-danger" style="margin-bottom:1rem">
      <?php foreach ($errors as $err): ?><div><?= e($err) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>

  <form method="post">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= e((string) ($edit['id'] ?? '')) ?>">

    <div class="grid grid-2">
      <div class="field">
        <label class="label">Tipo de documento</label>
        <?php $dt = (string) ($edit['documentType'] ?? 'CNPJ'); ?>
        <select class="input" name="documentType" required>
          <option value="CNPJ" <?= $dt === 'CNPJ' ? 'selected' : '' ?>>CNPJ</option>
          <option value="CPF" <?= $dt === 'CPF' ? 'selected' : '' ?>>CPF</option>
        </select>
      </div>
      <div class="field">
        <label class="label">CPF / CNPJ</label>
        <input class="input" name="document" value="<?= e((string) ($edit['document'] ?? '')) ?>" placeholder="00.000.000/0000-00" required>
      </div>
    </div>

    <div class="field">
      <label class="label">Razão social / Nome</label>
      <input class="input" name="name" value="<?= e((string) ($edit['name'] ?? '')) ?>" required>
    </div>
    <div class="field">
      <label class="label">Nome fantasia</label>
      <input class="input" name="tradeName" value="<?= e((string) ($edit['tradeName'] ?? '')) ?>">
    </div>

    <div class="grid grid-2">
      <div class="field">
        <label class="label">Contato</label>
        <input class="input" name="contactName" value="<?= e((string) ($edit['contactName'] ?? '')) ?>">
      </div>
      <div class="field">
        <label class="label">Telefone</label>
        <input class="input" name="phone" value="<?= e((string) ($edit['phone'] ?? '')) ?>">
      </div>
    </div>
    <div class="field">
      <label class="label">E-mail</label>
      <input class="input" type="email" name="email" value="<?= e((string) ($edit['email'] ?? '')) ?>">
    </div>

    <div class="grid grid-2">
      <div class="field">
        <label class="label">CEP</label>
        <input class="input" name="zipCode" value="<?= e((string) ($edit['zipCode'] ?? '')) ?>" placeholder="00000-000">
      </div>
      <div class="field">
        <label class="label">Logradouro</label>
        <input class="input" name="address" value="<?= e((string) ($edit['address'] ?? '')) ?>">
      </div>
    </div>
    <div class="grid grid-2">
      <div class="field">
        <label class="label">Número</label>
        <input class="input" name="addressNumber" value="<?= e((string) ($edit['addressNumber'] ?? '')) ?>">
      </div>
      <div class="field">
        <label class="label">Complemento</label>
        <input class="input" name="addressComplement" value="<?= e((string) ($edit['addressComplement'] ?? '')) ?>">
      </div>
    </div>
    <div class="grid grid-2">
      <div class="field">
        <label class="label">Bairro</label>
        <input class="input" name="neighborhood" value="<?= e((string) ($edit['neighborhood'] ?? '')) ?>">
      </div>
      <div class="field">
        <label class="label">Município</label>
        <input class="input" name="city" value="<?= e((string) ($edit['city'] ?? '')) ?>">
      </div>
    </div>
    <div class="grid grid-2">
      <div class="field">
        <label class="label">UF</label>
        <input class="input" name="state" maxlength="2" value="<?= e((string) ($edit['state'] ?? 'GO')) ?>">
      </div>
      <div class="field">
        <label class="label">Categoria / natureza (TSE)</label>
        <input class="input" name="category" value="<?= e((string) ($edit['category'] ?? '')) ?>" placeholder="Ex.: Publicidade por materiais impressos">
      </div>
    </div>
    <div class="grid grid-2">
      <div class="field">
        <label class="label">Inscrição estadual</label>
        <input class="input" name="stateRegistration" value="<?= e((string) ($edit['stateRegistration'] ?? '')) ?>">
      </div>
      <div class="field">
        <label class="label">Inscrição municipal</label>
        <input class="input" name="municipalRegistration" value="<?= e((string) ($edit['municipalRegistration'] ?? '')) ?>">
      </div>
    </div>
    <div class="field">
      <label class="label">Observações</label>
      <textarea class="input" name="notes" rows="3"><?= e((string) ($edit['notes'] ?? '')) ?></textarea>
    </div>

    <div class="row-actions">
      <button class="btn btn-primary" type="submit">Salvar fornecedor</button>
      <?php if ($edit): ?>
        <a class="btn btn-ghost" href="<?= e(url_path('admin/fornecedores.php')) ?>">Cancelar edição</a>
      <?php endif; ?>
    </div>
  </form>
</div>
<?php endif; ?>
<?php require dirname(__DIR__) . '/templates/admin_layout_end.php'; ?>
