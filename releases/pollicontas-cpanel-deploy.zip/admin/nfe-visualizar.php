<?php

declare(strict_types=1);

/**
 * Visualizar nota fiscal pela chave de acesso (ConsultaDANFE / SEFAZ).
 * Só abre quando o lançamento (ou parâmetro) tiver chave com 44 dígitos.
 *
 * URL oficial: https://consultadanfe.com/?chave={chave_acesso}
 */
require_once dirname(__DIR__) . '/bootstrap.php';

Auth::requireLogin('despesas');

$id = trim((string) get('id', ''));
$key = only_digits((string) get('chave', ''));

if ($id !== '') {
    $pdo = Database::pdo();
    $st = $pdo->prepare('SELECT nfeKey FROM `Expense` WHERE id = ? LIMIT 1');
    $st->execute([$id]);
    $row = $st->fetch();
    if (!$row) {
        flash_set('danger', 'Despesa não encontrada.');
        redirect('/admin/despesas.php');
    }
    $key = only_digits((string) ($row['nfeKey'] ?? ''));
}

if (!nfe_has_access_key($key)) {
    flash_set('danger', 'Este lançamento não possui chave de acesso da NF-e. Não há nota para visualizar.');
    redirect('/admin/despesas.php');
}

// Abre o DANFE real (PDF) no ConsultaDANFE — mesma tela do print enviado.
redirect('https://consultadanfe.com/?chave=' . rawurlencode($key));
